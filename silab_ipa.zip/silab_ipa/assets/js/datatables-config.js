$(document).ready(function () {

    $('.datatable').each(function () {

        var table = $(this);

        // Mencegah DataTables diinisialisasi dua kali
        if ($.fn.DataTable.isDataTable(table)) {
            return;
        }

        var dt = table.DataTable({

            // Layout standar DataTables 1.13
            dom: 'lfrtip',

            pageLength: 10,

            lengthMenu: [
                [5, 10, 25, 50, 100, -1],
                [5, 10, 25, 50, 100, "Semua"]
            ],

            ordering: true,

            searching: true,

            info: true,

            autoWidth: false,

            language: {

                search: "Cari:",

                lengthMenu: "Tampilkan _MENU_ data",

                info: "Menampilkan _START_ sampai _END_ dari _TOTAL_ data",

                infoEmpty: "Tidak ada data",

                infoFiltered: "(difilter dari _MAX_ total data)",

                zeroRecords: "Data tidak ditemukan",

                emptyTable: "Belum ada data",

                paginate: {
                    first: "Pertama",
                    last: "Terakhir",
                    next: "Berikutnya",
                    previous: "Sebelumnya"
                }

            },

            columnDefs: [

                {
                    targets: 0,
                    orderable: false,
                    searchable: false
                },

                {
                    targets: -1,
                    orderable: false,
                    searchable: false
                }

            ]

        });


        // Nomor urut otomatis
        dt.on(
            'order.dt search.dt draw.dt',
            function () {

                var info = dt.page.info();

                dt.column(0, {
                    page: 'current'
                })
                .nodes()
                .each(function (cell, i) {

                    cell.innerHTML =
                        info.start + i + 1;

                });

            }
        );

        dt.draw();

    });

});