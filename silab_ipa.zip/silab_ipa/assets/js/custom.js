// SweetAlert Flash Message
$(document).ready(function(){

    let flash = $("#flash-data").data("flashdata");

    if(flash){

        Swal.fire({

            icon:'success',

            title:'Berhasil',

            text:flash,

            timer:2000,

            showConfirmButton:false

        });

    }

});