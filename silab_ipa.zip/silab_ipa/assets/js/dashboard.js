document.getElementById('toggleSidebar').addEventListener('click',function(){

let sidebar=document.querySelector('.sidebar');

if(sidebar.style.marginLeft=="-250px"){

sidebar.style.marginLeft="0";

document.querySelector('.content').style.marginLeft="250px";

}else{

sidebar.style.marginLeft="-250px";

document.querySelector('.content').style.marginLeft="0";

}

});