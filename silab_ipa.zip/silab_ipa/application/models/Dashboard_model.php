<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Dashboard_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function count_laboratorium()
    {
        return $this->db->where('aktif', 1)->count_all_results('laboratorium');
    }

    public function count_alat()
    {
        return $this->db->where('aktif', 1)->count_all_results('alat');
    }

    public function count_unit_alat()
    {
        return $this->db->count_all_results('unit_alat');
    }

    public function count_bahan()
    {
        return $this->db->where('aktif', 1)->count_all_results('bahan');
    }

    public function get_unit_alat_by_kondisi()
    {
        $this->db->select('kondisi, COUNT(id) as total');
        $this->db->group_by('kondisi');
        return $this->db->get('unit_alat')->result();
    }

    public function get_laboratorium_ringkasan()
    {
        $this->db->select('l.*, 
            (SELECT COUNT(ua.id) FROM unit_alat ua WHERE ua.laboratorium_id = l.id) as total_alat,
            (SELECT COUNT(bb.id) FROM batch_bahan bb WHERE bb.laboratorium_id = l.id) as total_batch');
        $this->db->where('l.aktif', 1);
        $this->db->order_by('l.nama', 'ASC');
        return $this->db->get('laboratorium l')->result();
    }
}
