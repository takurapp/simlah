<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Peminjaman_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function get_all($user_id = null, $role = null)
    {
        $this->db->select('p.*, l.nama as nama_lab, u.nama_lengkap as nama_peminjam, petugas.nama_lengkap as nama_petugas, COUNT(d.id) as total_alat');
        $this->db->from('peminjaman_alat p');
        $this->db->join('laboratorium l', 'l.id = p.laboratorium_id', 'left');
        $this->db->join('users u', 'u.id = p.user_id', 'left');
        $this->db->join('users petugas', 'petugas.id = p.laboran_id', 'left');
        $this->db->join('detail_peminjaman_alat d', 'd.peminjaman_id = p.id', 'left');

        // Jika login sebagai guru, hanya tampilkan peminjaman miliknya sendiri
        if ($role === 'guru' && $user_id !== null) {
            $this->db->where('p.user_id', (int) $user_id);
        }

        $this->db->group_by('p.id');
        $this->db->order_by('p.id', 'DESC');
        return $this->db->get()->result();
    }

    public function get_by_id($id)
    {
        $this->db->select('p.*, l.nama as nama_lab, u.nama_lengkap as nama_peminjam, petugas.nama_lengkap as nama_petugas');
        $this->db->from('peminjaman_alat p');
        $this->db->join('laboratorium l', 'l.id = p.laboratorium_id', 'left');
        $this->db->join('users u', 'u.id = p.user_id', 'left');
        $this->db->join('users petugas', 'petugas.id = p.laboran_id', 'left');
        $this->db->where('p.id', (int) $id);
        return $this->db->get()->row();
    }

    public function get_detail_items($peminjaman_id)
    {
        $this->db->select('d.*, ua.nomor_inventaris, ua.nomor_seri, a.nama as nama_alat, a.merek');
        $this->db->from('detail_peminjaman_alat d');
        $this->db->join('unit_alat ua', 'ua.id = d.unit_alat_id', 'left');
        $this->db->join('alat a', 'a.id = ua.alat_id', 'left');
        $this->db->where('d.peminjaman_id', (int) $peminjaman_id);
        return $this->db->get()->result();
    }

    public function get_unit_tersedia($laboratorium_id = null)
    {
        $this->db->select('ua.*, a.nama as nama_alat, a.merek, l.nama as nama_lab');
        $this->db->from('unit_alat ua');
        $this->db->join('alat a', 'a.id = ua.alat_id', 'left');
        $this->db->join('laboratorium l', 'l.id = ua.laboratorium_id', 'left');
        $this->db->where('ua.status', 'tersedia');
        $this->db->where('ua.kondisi !=', 'rusak_berat');

        if ($laboratorium_id) {
            $this->db->where('ua.laboratorium_id', (int) $laboratorium_id);
        }

        $this->db->order_by('a.nama', 'ASC');
        return $this->db->get()->result();
    }

    public function insert_pengajuan($data_peminjaman, $unit_ids)
    {
        $this->db->trans_start();

        $this->db->insert('peminjaman_alat', $data_peminjaman);
        $peminjaman_id = $this->db->insert_id();

        foreach ($unit_ids as $unit_id) {
            $unit = $this->db->get_where('unit_alat', array('id' => (int) $unit_id))->row();
            $detail = array(
                'peminjaman_id'  => $peminjaman_id,
                'unit_alat_id'   => (int) $unit_id,
                'kondisi_keluar' => $unit ? $unit->kondisi : 'baik'
            );
            $this->db->insert('detail_peminjaman_alat', $detail);

            // Ubah status unit alat menjadi dipinjam
            $this->db->where('id', (int) $unit_id)->update('unit_alat', array(
                'status'     => 'dipinjam',
                'updated_at' => date('Y-m-d H:i:s')
            ));
        }

        $this->db->trans_complete();
        return $this->db->trans_status();
    }

    public function proses_kembali($peminjaman_id, $petugas_id, $kondisi_data, $catatan_data)
    {
        $this->db->trans_start();

        // 1. Update data pengembalian pada detail item
        foreach ($kondisi_data as $detail_id => $kondisi_kembali) {
            $catatan = isset($catatan_data[$detail_id]) ? $catatan_data[$detail_id] : null;

            $this->db->where('id', (int) $detail_id)->update('detail_peminjaman_alat', array(
                'kondisi_kembali' => $kondisi_kembali,
                'catatan'         => $catatan
            ));

            // Kembalikan status unit_alat menjadi tersedia serta perbarui kondisi terkininya
            $detail = $this->db->get_where('detail_peminjaman_alat', array('id' => (int) $detail_id))->row();
            if ($detail) {
                $status_baru = ($kondisi_kembali === 'rusak_berat') ? 'rusak' : 'tersedia';
                $this->db->where('id', $detail->unit_alat_id)->update('unit_alat', array(
                    'status'     => $status_baru,
                    'kondisi'    => $kondisi_kembali,
                    'updated_at' => date('Y-m-d H:i:s')
                ));
            }
        }

        // 2. Update status master peminjaman menjadi selesai
        $this->db->where('id', (int) $peminjaman_id)->update('peminjaman_alat', array(
            'status'          => 'selesai',
            'tanggal_kembali' => date('Y-m-d H:i:s'),
            'laboran_id'      => (int) $petugas_id,
            'updated_at'      => date('Y-m-d H:i:s')
        ));

        $this->db->trans_complete();
        return $this->db->trans_status();
    }
}
