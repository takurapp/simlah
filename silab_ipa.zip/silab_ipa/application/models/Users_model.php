
<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Users_model extends CI_Model
{
    public function get_all()
    {
        return $this->db
            ->order_by('nama_lengkap', 'ASC')
            ->get('users')
            ->result();
    }

    public function get_by_id($id)
    {
        return $this->db
            ->where('id', (int) $id)
            ->get('users')
            ->row();
    }

    public function username_exists($username, $except_id = 0)
    {
        $this->db->where('username', $username);

        if ($except_id > 0) {
            $this->db->where('id !=', $except_id);
        }

        return $this->db->count_all_results('users') > 0;
    }

    public function create($data)
    {
        return $this->db->insert('users', $data);
    }

    public function update_user($id, $data)
    {
        return $this->db
            ->where('id', (int) $id)
            ->update('users', $data);
    }

    public function set_active($id, $aktif)
    {
        return $this->db
            ->where('id', (int) $id)
            ->update('users', array(
                'aktif' => (int) $aktif,
                'updated_at' => date('Y-m-d H:i:s')
            ));
    }
}
