<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Jadwal_model extends CI_Model
{
    protected $table = 'jadwal_laboratorium';

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function get_all($lab_id = null, $tanggal = null)
    {
        $this->db->select('j.*, l.nama as nama_lab, u.nama_lengkap as nama_guru');
        $this->db->from($this->table . ' j');
        $this->db->join('laboratorium l', 'l.id = j.laboratorium_id', 'left');
        $this->db->join('users u', 'u.id = j.user_id', 'left');

        if (!empty($lab_id)) {
            $this->db->where('j.laboratorium_id', (int) $lab_id);
        }

        if (!empty($tanggal)) {
            $this->db->where('j.tanggal', $tanggal);
        }

        $this->db->order_by('j.tanggal', 'DESC');
        $this->db->order_by('j.jam_mulai', 'ASC');
        return $this->db->get()->result();
    }

    public function get_by_id($id)
    {
        $this->db->select('j.*, l.nama as nama_lab, u.nama_lengkap as nama_guru');
        $this->db->from($this->table . ' j');
        $this->db->join('laboratorium l', 'l.id = j.laboratorium_id', 'left');
        $this->db->join('users u', 'u.id = j.user_id', 'left');
        $this->db->where('j.id', (int) $id);
        return $this->db->get()->row();
    }

    // Deteksi bentrok jadwal di ruang lab yang sama pada tanggal & rentang jam tertentu
    public function check_bentrok($laboratorium_id, $tanggal, $jam_mulai, $jam_selesai, $exclude_id = null)
    {
        $this->db->where('laboratorium_id', (int) $laboratorium_id);
        $this->db->where('tanggal', $tanggal);
        $this->db->where('status !=', 'dibatalkan');

        // Logika overlap: (Mulai_A < Selesai_B) AND (Selesai_A > Mulai_B)
        $this->db->where("('$jam_mulai' < jam_selesai AND '$jam_selesai' > jam_mulai)");

        if ($exclude_id !== null) {
            $this->db->where('id !=', (int) $exclude_id);
        }

        return $this->db->count_all_results($this->table) > 0;
    }

    public function insert($data)
    {
        return $this->db->insert($this->table, $data);
    }

    public function update($id, $data)
    {
        $this->db->where('id', (int) $id);
        return $this->db->update($this->table, $data);
    }

    public function delete($id)
    {
        $this->db->where('id', (int) $id);
        return $this->db->delete($this->table);
    }
}
