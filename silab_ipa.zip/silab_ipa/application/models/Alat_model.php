<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Alat_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function get_all()
    {
        $this->db->select('a.*, ka.nama as kategori_nama, COUNT(ua.id) as total_unit');
        $this->db->from('alat a');
        $this->db->join('kategori_alat ka', 'ka.id = a.kategori_alat_id', 'left');
        $this->db->join('unit_alat ua', 'ua.alat_id = a.id', 'left');
        $this->db->group_by('a.id');
        $this->db->order_by('a.nama', 'ASC');
        return $this->db->get()->result();
    }

    public function get_by_id($id)
    {
        $this->db->select('a.*, ka.nama as kategori_nama');
        $this->db->from('alat a');
        $this->db->join('kategori_alat ka', 'ka.id = a.kategori_alat_id', 'left');
        $this->db->where('a.id', (int) $id);
        return $this->db->get()->row();
    }

    public function insert($data)
    {
        $data['created_at'] = date('Y-m-d H:i:s');
        $data['updated_at'] = date('Y-m-d H:i:s');
        return $this->db->insert('alat', $data);
    }

    public function update($id, $data)
    {
        $data['updated_at'] = date('Y-m-d H:i:s');
        $this->db->where('id', (int) $id);
        return $this->db->update('alat', $data);
    }

    public function delete($id)
    {
        $unit_count = $this->db->where('alat_id', (int) $id)->count_all_results('unit_alat');
        if ($unit_count > 0) {
            return false;
        }
        $this->db->where('id', (int) $id);
        return $this->db->delete('alat');
    }

    // Manajemen Unit Fisik Alat
    public function get_units_by_alat_id($alat_id)
    {
        $this->db->select('ua.*, l.nama as lab_nama');
        $this->db->from('unit_alat ua');
        $this->db->join('laboratorium l', 'l.id = ua.laboratorium_id', 'left');
        $this->db->where('ua.alat_id', (int) $alat_id);
        $this->db->order_by('ua.nomor_inventaris', 'ASC');
        return $this->db->get()->result();
    }

    public function insert_unit($data)
    {
        $data['created_at'] = date('Y-m-d H:i:s');
        $data['updated_at'] = date('Y-m-d H:i:s');
        return $this->db->insert('unit_alat', $data);
    }

    public function update_unit($id, $data)
    {
        $data['updated_at'] = date('Y-m-d H:i:s');
        $this->db->where('id', (int) $id);
        return $this->db->update('unit_alat', $data);
    }

    public function delete_unit($id)
    {
        $this->db->where('id', (int) $id);
        return $this->db->delete('unit_alat');
    }
}
