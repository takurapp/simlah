<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Laboratorium_model extends CI_Model
{
    protected $table = 'laboratorium';

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function get_all($active_only = false)
    {
        if ($active_only) {
            $this->db->where('aktif', 1);
        }
        $this->db->order_by('nama', 'ASC');
        return $this->db->get($this->table)->result();
    }

    public function get_by_id($id)
    {
        return $this->db->get_where($this->table, array('id' => (int) $id))->row();
    }

    public function insert($data)
    {
        $data['created_at'] = date('Y-m-d H:i:s');
        $data['updated_at'] = date('Y-m-d H:i:s');
        return $this->db->insert($this->table, $data);
    }

    public function update($id, $data)
    {
        $data['updated_at'] = date('Y-m-d H:i:s');
        $this->db->where('id', (int) $id);
        return $this->db->update($this->table, $data);
    }

    public function delete($id)
    {
        // Pastikan tidak ada unit alat atau batch bahan yang terikat sebelum menghapus
        $this->db->where('id', (int) $id);
        return $this->db->delete($this->table);
    }

    public function check_usage($id)
    {
        $unit_alat_count = $this->db->where('laboratorium_id', (int) $id)->count_all_results('unit_alat');
        $batch_bahan_count = $this->db->where('laboratorium_id', (int) $id)->count_all_results('batch_bahan');
        return ($unit_alat_count > 0 || $batch_bahan_count > 0);
    }
}
