<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Kategori_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    // Kategori Alat
    public function get_kategori_alat()
    {
        $this->db->order_by('nama', 'ASC');
        return $this->db->get('kategori_alat')->result();
    }

    public function insert_kategori_alat($data)
    {
        $data['created_at'] = date('Y-m-d H:i:s');
        $data['updated_at'] = date('Y-m-d H:i:s');
        return $this->db->insert('kategori_alat', $data);
    }

    public function delete_kategori_alat($id)
    {
        $terpakai = $this->db->where('kategori_alat_id', (int) $id)->count_all_results('alat');
        if ($terpakai > 0) {
            return false;
        }
        $this->db->where('id', (int) $id);
        return $this->db->delete('kategori_alat');
    }

    // Kategori Bahan
    public function get_kategori_bahan()
    {
        $this->db->order_by('nama', 'ASC');
        return $this->db->get('kategori_bahan')->result();
    }

    public function insert_kategori_bahan($data)
    {
        $data['created_at'] = date('Y-m-d H:i:s');
        $data['updated_at'] = date('Y-m-d H:i:s');
        return $this->db->insert('kategori_bahan', $data);
    }

    public function delete_kategori_bahan($id)
    {
        $terpakai = $this->db->where('kategori_bahan_id', (int) $id)->count_all_results('bahan');
        if ($terpakai > 0) {
            return false;
        }
        $this->db->where('id', (int) $id);
        return $this->db->delete('kategori_bahan');
    }

    // Satuan Bahan
    public function get_satuan()
    {
        $this->db->order_by('nama', 'ASC');
        return $this->db->get('satuan')->result();
    }

    public function insert_satuan($data)
    {
        $data['created_at'] = date('Y-m-d H:i:s');
        $data['updated_at'] = date('Y-m-d H:i:s');
        return $this->db->insert('satuan', $data);
    }
}
