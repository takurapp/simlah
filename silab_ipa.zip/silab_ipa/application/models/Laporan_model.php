<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Laporan_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function get_laporan_peminjaman($tgl_mulai = null, $tgl_selesai = null, $lab_id = null, $status = null)
    {
        $this->db->select('p.*, l.nama as nama_lab, u.nama_lengkap as nama_peminjam, petugas.nama_lengkap as nama_petugas, COUNT(d.id) as total_alat');
        $this->db->from('peminjaman_alat p');
        $this->db->join('laboratorium l', 'l.id = p.laboratorium_id', 'left');
        $this->db->join('users u', 'u.id = p.user_id', 'left');
        $this->db->join('users petugas', 'petugas.id = p.laboran_id', 'left');
        $this->db->join('detail_peminjaman_alat d', 'd.peminjaman_id = p.id', 'left');

        if (!empty($tgl_mulai)) {
            $this->db->where('DATE(p.tanggal_pinjam) >=', $tgl_mulai);
        }
        if (!empty($tgl_selesai)) {
            $this->db->where('DATE(p.tanggal_pinjam) <=', $tgl_selesai);
        }
        if (!empty($lab_id)) {
            $this->db->where('p.laboratorium_id', (int) $lab_id);
        }
        if (!empty($status)) {
            $this->db->where('p.status', $status);
        }

        $this->db->group_by('p.id');
        $this->db->order_by('p.tanggal_pinjam', 'DESC');
        return $this->db->get()->result();
    }

    public function get_laporan_mutasi_bahan($tgl_mulai = null, $tgl_selesai = null, $bahan_id = null, $jenis = null)
    {
        $this->db->select('tb.*, b.nama as nama_bahan, b.kode as kode_bahan, s.simbol as satuan_simbol, bb.nomor_batch, u.nama_lengkap as operator');
        $this->db->from('transaksi_bahan tb');
        $this->db->join('batch_bahan bb', 'bb.id = tb.batch_bahan_id', 'left');
        $this->db->join('bahan b', 'b.id = bb.bahan_id', 'left');
        $this->db->join('satuan s', 's.id = b.satuan_id', 'left');
        $this->db->join('users u', 'u.id = tb.user_id', 'left');

        if (!empty($tgl_mulai)) {
            $this->db->where('DATE(tb.tanggal_transaksi) >=', $tgl_mulai);
        }
        if (!empty($tgl_selesai)) {
            $this->db->where('DATE(tb.tanggal_transaksi) <=', $tgl_selesai);
        }
        if (!empty($bahan_id)) {
            $this->db->where('bb.bahan_id', (int) $bahan_id);
        }
        if (!empty($jenis)) {
            $this->db->where('tb.jenis', $jenis);
        }

        $this->db->order_by('tb.tanggal_transaksi', 'DESC');
        return $this->db->get()->result();
    }
}
