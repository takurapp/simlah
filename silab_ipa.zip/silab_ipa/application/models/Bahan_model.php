<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Bahan_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function get_all()
    {
        $this->db->select('b.*, kb.nama as kategori_nama, s.simbol as satuan_simbol, 
            COALESCE(SUM(bb.jumlah_tersedia), 0) as total_stok');
        $this->db->from('bahan b');
        $this->db->join('kategori_bahan kb', 'kb.id = b.kategori_bahan_id', 'left');
        $this->db->join('satuan s', 's.id = b.satuan_id', 'left');
        $this->db->join('batch_bahan bb', 'bb.bahan_id = b.id', 'left');
        $this->db->group_by('b.id');
        $this->db->order_by('b.nama', 'ASC');
        return $this->db->get()->result();
    }

    public function get_by_id($id)
    {
        $this->db->select('b.*, kb.nama as kategori_nama, s.nama as satuan_nama, s.simbol as satuan_simbol');
        $this->db->from('bahan b');
        $this->db->join('kategori_bahan kb', 'kb.id = b.kategori_bahan_id', 'left');
        $this->db->join('satuan s', 's.id = b.satuan_id', 'left');
        $this->db->where('b.id', (int) $id);
        return $this->db->get()->row();
    }

    public function insert($data)
    {
        $data['created_at'] = date('Y-m-d H:i:s');
        $data['updated_at'] = date('Y-m-d H:i:s');
        return $this->db->insert('bahan', $data);
    }

    public function update($id, $data)
    {
        $data['updated_at'] = date('Y-m-d H:i:s');
        $this->db->where('id', (int) $id);
        return $this->db->update('bahan', $data);
    }

    public function delete($id)
    {
        $batch_count = $this->db->where('bahan_id', (int) $id)->count_all_results('batch_bahan');
        if ($batch_count > 0) {
            return false;
        }
        $this->db->where('id', (int) $id);
        return $this->db->delete('bahan');
    }

    // Manajemen Batch & Stok Bahan
    public function get_batches_by_bahan_id($bahan_id)
    {
        $this->db->select('bb.*, l.nama as lab_nama');
        $this->db->from('batch_bahan bb');
        $this->db->join('laboratorium l', 'l.id = bb.laboratorium_id', 'left');
        $this->db->where('bb.bahan_id', (int) $bahan_id);
        $this->db->order_by('bb.tanggal_kedaluwarsa', 'ASC');
        return $this->db->get()->result();
    }

    public function get_batch_by_id($batch_id)
    {
        return $this->db->get_where('batch_bahan', array('id' => (int) $batch_id))->row();
    }

    public function insert_batch_with_transaksi($data_batch, $user_id)
    {
        $this->db->trans_start();

        $data_batch['created_at'] = date('Y-m-d H:i:s');
        $data_batch['updated_at'] = date('Y-m-d H:i:s');
        $this->db->insert('batch_bahan', $data_batch);
        $batch_id = $this->db->insert_id();

        // Catat transaksi masuk perdana
        $transaksi = array(
            'batch_bahan_id'    => $batch_id,
            'user_id'           => $user_id,
            'jenis'             => 'masuk',
            'jumlah'            => $data_batch['jumlah_awal'],
            'tanggal_transaksi' => date('Y-m-d H:i:s'),
            'nomor_referensi'   => 'BATCH-INIT-' . $batch_id,
            'alasan'            => 'Penerimaan stok awal batch ' . $data_batch['nomor_batch'],
            'created_at'        => date('Y-m-d H:i:s'),
            'updated_at'        => date('Y-m-d H:i:s')
        );
        $this->db->insert('transaksi_bahan', $transaksi);

        $this->db->trans_complete();
        return $this->db->trans_status();
    }

    public function record_pengurangan_stok($batch_id, $jumlah, $user_id, $alasan)
    {
        $this->db->trans_start();

        $batch = $this->get_batch_by_id($batch_id);
        if (!$batch || (float)$batch->jumlah_tersedia < (float)$jumlah) {
            $this->db->trans_rollback();
            return false;
        }

        // Potong stok tersedia
        $sisa = (float)$batch->jumlah_tersedia - (float)$jumlah;
        $this->db->where('id', (int) $batch_id)->update('batch_bahan', array(
            'jumlah_tersedia' => $sisa,
            'updated_at'      => date('Y-m-d H:i:s')
        ));

        // Catat ke log transaksi bahan
        $transaksi = array(
            'batch_bahan_id'    => (int) $batch_id,
            'user_id'           => (int) $user_id,
            'jenis'             => 'keluar',
            'jumlah'            => (float) $jumlah,
            'tanggal_transaksi' => date('Y-m-d H:i:s'),
            'alasan'            => $alasan,
            'created_at'        => date('Y-m-d H:i:s'),
            'updated_at'        => date('Y-m-d H:i:s')
        );
        $this->db->insert('transaksi_bahan', $transaksi);

        $this->db->trans_complete();
        return $this->db->trans_status();
    }
}
