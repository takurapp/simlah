
<?php
defined('BASEPATH') or exit('No direct script access allowed');

class MY_Controller extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        $this->load->library('session');
        $this->load->helper('url');

        if (!$this->session->userdata('logged_in')) {
            redirect('auth');
        }
    }
}

class Admin_Controller extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();

        if ($this->session->userdata('role') !== 'admin') {
            show_error(
                'Anda tidak memiliki hak akses ke halaman ini.',
                403,
                'Akses Ditolak'
            );
        }
    }
}

class Laboran_Controller extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();

        if (!in_array(
            $this->session->userdata('role'),
            array('admin', 'laboran'),
            TRUE
        )) {
            show_error(
                'Anda tidak memiliki hak akses ke halaman ini.',
                403,
                'Akses Ditolak'
            );
        }
    }
}

class Guru_Controller extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();

        if (!in_array(
            $this->session->userdata('role'),
            array('admin', 'guru'),
            TRUE
        )) {
            show_error(
                'Anda tidak memiliki hak akses ke halaman ini.',
                403,
                'Akses Ditolak'
            );
        }
    }
}
