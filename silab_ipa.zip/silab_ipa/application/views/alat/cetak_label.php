<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="utf-8">
    <title>Cetak Label Inventaris - <?= html_escape($alat->nama); ?></title>
    <!-- JsBarcode CDN untuk render barcode visual -->
    <script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.5/dist/JsBarcode.all.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 10px;
            background: #f8f9fa;
        }

        .label-grid {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
        }

        .label-card {
            width: 250px;
            border: 2px solid #222;
            border-radius: 6px;
            padding: 8px;
            background: #fff;
            box-sizing: border-box;
            page-break-inside: avoid;
        }

        .label-title {
            font-size: 11px;
            font-weight: bold;
            text-align: center;
            border-bottom: 1px solid #444;
            padding-bottom: 4px;
            margin-bottom: 6px;
            text-transform: uppercase;
        }

        .label-name {
            font-size: 13px;
            font-weight: bold;
            margin-bottom: 2px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .label-meta {
            font-size: 10px;
            color: #444;
            margin-bottom: 6px;
        }

        .barcode-container {
            text-align: center;
        }

        .barcode-container svg {
            max-width: 100%;
            height: 45px;
        }

        @media print {
            body {
                background: none;
                padding: 0;
            }

            .no-print {
                display: none;
            }

            .label-card {
                border: 1.5px solid #000;
            }
        }
    </style>
</head>

<body>

    <div class="no-print" style="margin-bottom: 15px;">
        <button onclick="window.print()" style="padding: 8px 16px; background: #007bff; color: white; border: none; border-radius: 4px; cursor: pointer;">
            Cetak Label
        </button>
        <button onclick="window.close()" style="padding: 8px 16px; background: #6c757d; color: white; border: none; border-radius: 4px; cursor: pointer; margin-left: 6px;">
            Tutup
        </button>
    </div>

    <div class="label-grid">
        <?php foreach ($units as $u): ?>
            <div class="label-card">
                <div class="label-title">Aset Laboratorium IPA</div>
                <div class="label-name"><?= html_escape($alat->nama); ?></div>
                <div class="label-meta">
                    Lokasi: <?= html_escape($u->lab_nama ?: 'Gudang Utama'); ?><br>
                    Perolehan: <?= html_escape($u->tanggal_perolehan ?: '-'); ?>
                </div>
                <div class="barcode-container">
                    <svg class="barcode"
                        jsbarcode-value="<?= html_escape($u->nomor_inventaris); ?>"
                        jsbarcode-format="CODE128"
                        jsbarcode-width="1.4"
                        jsbarcode-height="35"
                        jsbarcode-fontsize="11">
                    </svg>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <script>
        JsBarcode(".barcode").init();
        window.addEventListener('load', function() {
            setTimeout(function() {
                window.print();
            }, 400);
        });
    </script>
</body>

</html>