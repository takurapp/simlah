<?php
$this->load->view('layout/header');
$this->load->view('layout/navbar');
$this->load->view('layout/sidebar');
?>

<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 font-weight-bold"><?= html_escape($judul); ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?= site_url('dashboard'); ?>">Home</a></li>
                        <li class="breadcrumb-item active">Alat</li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="container-fluid">

            <?php if ($this->session->flashdata('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="icon fas fa-check mr-1"></i> <?= html_escape($this->session->flashdata('success')); ?>
                    <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span></button>
                </div>
            <?php endif; ?>

            <?php if ($this->session->flashdata('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="icon fas fa-ban mr-1"></i> <?= html_escape($this->session->flashdata('error')); ?>
                    <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span></button>
                </div>
            <?php endif; ?>

            <div class="card card-outline card-primary">
                <div class="card-header">
                    <h3 class="card-title font-weight-bold">Daftar Katalog Alat</h3>
                    <div class="card-tools">
                        <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#modal-tambah-alat">
                            <i class="fas fa-plus mr-1"></i> Tambah Master Alat
                        </button>
                    </div>
                </div>
                <div class="card-body">
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th style="width: 40px;">No</th>
                                <th>Kode</th>
                                <th>Nama Alat</th>
                                <th>Kategori</th>
                                <th>Merek / Spek</th>
                                <th>Jumlah Unit</th>
                                <th style="width: 140px;" class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($alat)): ?>
                                <tr>
                                    <td colspan="7" class="text-center text-muted">Belum ada katalog alat.</td>
                                </tr>
                            <?php else: ?>
                                <?php $no = 1;
                                foreach ($alat as $item): ?>
                                    <tr>
                                        <td><?= $no++; ?></td>
                                        <td><span class="badge badge-secondary"><?= html_escape($item->kode); ?></span></td>
                                        <td><strong><?= html_escape($item->nama); ?></strong></td>
                                        <td><?= html_escape($item->kategori_nama ?: '-'); ?></td>
                                        <td><?= html_escape(($item->merek ? $item->merek . ' - ' : '') . ($item->spesifikasi ?: '-')); ?></td>
                                        <td>
                                            <span class="badge badge-info p-2"><?= html_escape($item->satuan); ?></span>
                                        </td>
                                        <td class="text-center">
                                            <a href="<?= site_url('alat/detail/' . $item->id); ?>" class="btn btn-info btn-sm" title="Kelola Unit Fisik">
                                                <i class="fas fa-boxes"></i>
                                            </a>
                                            <a href="<?= site_url('alat/edit/' . $item->id); ?>" class="btn btn-warning btn-sm text-white" title="Edit Master Alat">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <form action="<?= site_url('alat/hapus/' . $item->id); ?>" method="post" class="d-inline" onsubmit="return confirm('Hapus master alat ini?');">
                                                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
                                                <button type="submit" class="btn btn-danger btn-sm" title="Hapus"><i class="fas fa-trash"></i></button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </section>
</div>

<!-- Modal Tambah Master Alat -->
<div class="modal fade" id="modal-tambah-alat" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form action="<?= site_url('alat/simpan'); ?>" method="post">
                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
                <div class="modal-header">
                    <h5 class="modal-title font-weight-bold">Tambah Katalog Alat IPA</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 form-group">
                            <label>Kode Alat <span class="text-danger">*</span></label>
                            <input type="text" name="kode" class="form-control" placeholder="Cth: ALT-MIK-01" required>
                        </div>
                        <div class="col-md-6 form-group">
                            <label>Kategori Alat <span class="text-danger">*</span></label>
                            <select name="kategori_alat_id" class="form-control" required>
                                <option value="">-- Pilih Kategori --</option>
                                <?php foreach ($kategori_alat as $kat): ?>
                                    <option value="<?= $kat->id; ?>"><?= html_escape($kat->nama); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Nama Alat <span class="text-danger">*</span></label>
                        <input type="text" name="nama" class="form-control" placeholder="Cth: Mikroskop Binokuler Siswa" required>
                    </div>
                    <div class="row">
                        <div class="col-md-6 form-group">
                            <label>Merek</label>
                            <input type="text" name="merek" class="form-control" placeholder="Cth: Olympus / Yazumi">
                        </div>
                        <div class="col-md-6 form-group">
                            <label>Satuan</label>
                            <input type="text" name="satuan" class="form-control" value="1" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Spesifikasi Ringkas</label>
                        <input type="text" name="spesifikasi" class="form-control" placeholder="Cth: Pembesaran 40x - 1000x, Lampu LED">
                    </div>
                    <div class="form-group">
                        <label>Keterangan</label>
                        <textarea name="keterangan" class="form-control" rows="2"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                    <button type="submit" class="btn btn-primary">Simpan Master Alat</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $this->load->view('layout/footer'); ?>