<?php
$this->load->view('layout/header');
$this->load->view('layout/navbar');
$this->load->view('layout/sidebar');
?>

<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 font-weight-bold"><?= html_escape($judul); ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?= site_url('dashboard'); ?>">Home</a></li>
                        <li class="breadcrumb-item"><a href="<?= site_url('alat'); ?>">Alat</a></li>
                        <li class="breadcrumb-item active">Edit</li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-8">
                    <div class="card card-warning">
                        <div class="card-header">
                            <h3 class="card-title text-white font-weight-bold">Form Edit Data Alat</h3>
                        </div>

                        <?= validation_errors('<div class="alert alert-danger m-3"><i class="fas fa-exclamation-triangle mr-1"></i> ', '</div>'); ?>

                        <form action="<?= site_url('alat/update/' . $alat->id); ?>" method="post">
                            <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">

                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label for="kode">Kode Alat <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="kode" name="kode" value="<?= set_value('kode', $alat->kode); ?>" required>
                                    </div>
                                    <div class="col-md-6 form-group">
                                        <label for="kategori_alat_id">Kategori Alat <span class="text-danger">*</span></label>
                                        <select class="form-control" id="kategori_alat_id" name="kategori_alat_id" required>
                                            <option value="">-- Pilih Kategori --</option>
                                            <?php foreach ($kategori_alat as $kat): ?>
                                                <option value="<?= $kat->id; ?>" <?= set_select('kategori_alat_id', $kat->id, ($kat->id == $alat->kategori_alat_id)); ?>>
                                                    <?= html_escape($kat->nama); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="nama">Nama Alat <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="nama" name="nama" value="<?= set_value('nama', $alat->nama); ?>" required>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label for="merek">Merek</label>
                                        <input type="text" class="form-control" id="merek" name="merek" value="<?= set_value('merek', $alat->merek); ?>">
                                    </div>
                                    <div class="col-md-6 form-group">
                                        <label for="satuan">Satuan</label>
                                        <input type="text" class="form-control" id="satuan" name="satuan" value="<?= set_value('satuan', $alat->satuan); ?>" required>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="spesifikasi">Spesifikasi Ringkas</label>
                                    <input type="text" class="form-control" id="spesifikasi" name="spesifikasi" value="<?= set_value('spesifikasi', $alat->spesifikasi); ?>">
                                </div>

                                <div class="form-group">
                                    <label for="keterangan">Keterangan</label>
                                    <textarea class="form-control" id="keterangan" name="keterangan" rows="3"><?= set_value('keterangan', $alat->keterangan); ?></textarea>
                                </div>
                            </div>

                            <div class="card-footer">
                                <button type="submit" class="btn btn-warning text-white"><i class="fas fa-save mr-1"></i> Perbarui</button>
                                <a href="<?= site_url('alat'); ?>" class="btn btn-secondary ml-2"><i class="fas fa-arrow-left mr-1"></i> Batal</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<?php $this->load->view('layout/footer'); ?>