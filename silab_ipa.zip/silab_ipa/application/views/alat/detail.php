<?php
$this->load->view('layout/header');
$this->load->view('layout/navbar');
$this->load->view('layout/sidebar');
?>

<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 font-weight-bold">Inventaris Unit Alat</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?= site_url('dashboard'); ?>">Home</a></li>
                        <li class="breadcrumb-item"><a href="<?= site_url('alat'); ?>">Alat</a></li>
                        <li class="breadcrumb-item active">Unit</li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="container-fluid">

            <?php if ($this->session->flashdata('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="icon fas fa-check mr-1"></i> <?= html_escape($this->session->flashdata('success')); ?>
                    <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span></button>
                </div>
            <?php endif; ?>

            <?php if ($this->session->flashdata('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="icon fas fa-ban mr-1"></i> <?= html_escape($this->session->flashdata('error')); ?>
                    <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span></button>
                </div>
            <?php endif; ?>

            <!-- Info Singkat Master Alat -->
            <div class="card card-outline card-info">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-3"><strong>Kode Alat:</strong> <?= html_escape($alat->kode); ?></div>
                        <div class="col-md-3"><strong>Nama:</strong> <?= html_escape($alat->nama); ?></div>
                        <div class="col-md-3"><strong>Kategori:</strong> <?= html_escape($alat->kategori_nama); ?></div>
                        <div class="col-md-3"><strong>Merek:</strong> <?= html_escape($alat->merek ?: '-'); ?></div>
                    </div>
                </div>
            </div>

            <!-- Tabel Unit Fisik -->
            <div class="card card-outline card-primary">
                <div class="card-header">
                    <h3 class="card-title font-weight-bold">Unit Fisik Terdaftar</h3>
                    <div class="card-tools">
                        <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#modal-tambah-unit">
                            <i class="fas fa-plus mr-1"></i> Registrasi Nomor Inventaris
                        </button>
                        <a href="<?= site_url('alat/cetak_label/' . $alat->id); ?>" target="_blank" class="btn btn-default btn-sm mr-1">
                            <i class="fas fa-barcode mr-1"></i> Cetak Semua Label
                        </a>
                        <a href="<?= site_url('alat'); ?>" class="btn btn-secondary btn-sm ml-1">
                            <i class="fas fa-arrow-left mr-1"></i> Kembali
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th style="width: 40px;">No</th>
                                <th>No. Inventaris / Barcode</th>
                                <th>No. Seri</th>
                                <th>Penempatan Lab</th>
                                <th>Kondisi</th>
                                <th>Status</th>
                                <th style="width: 90px;" class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($units)): ?>
                                <tr>
                                    <td colspan="7" class="text-center text-muted">Belum ada unit fisik terdaftar untuk alat ini.</td>
                                </tr>
                            <?php else: ?>
                                <?php $no = 1;
                                foreach ($units as $u): ?>
                                    <tr>
                                        <td><?= $no++; ?></td>
                                        <td><strong><?= html_escape($u->nomor_inventaris); ?></strong></td>
                                        <td><?= html_escape($u->nomor_seri ?: '-'); ?></td>
                                        <td><?= html_escape($u->lab_nama ?: 'Gudang Utama / Belum Ditentukan'); ?></td>
                                        <td>
                                            <?php if ($u->kondisi === 'baik'): ?>
                                                <span class="badge badge-success">Baik</span>
                                            <?php elseif ($u->kondisi === 'rusak_ringan'): ?>
                                                <span class="badge badge-warning">Rusak Ringan</span>
                                            <?php else: ?>
                                                <span class="badge badge-danger">Rusak Berat</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($u->status === 'tersedia'): ?>
                                                <span class="badge badge-primary">Tersedia</span>
                                            <?php elseif ($u->status === 'dipinjam'): ?>
                                                <span class="badge badge-secondary">Dipinjam</span>
                                            <?php else: ?>
                                                <span class="badge badge-dark"><?= ucfirst($u->status); ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center">
                                            <a href="<?= site_url('alat/cetak_label/' . $alat->id . '/' . $u->id); ?>" target="_blank" class="btn btn-default btn-sm" title="Cetak Label Ini">
                                                <i class="fas fa-barcode"></i>
                                            </a>
                                            <form action="<?= site_url('alat/hapus_unit/' . $alat->id . '/' . $u->id); ?>" method="post" class="d-inline" onsubmit="return confirm('Hapus unit inventaris ini?');">
                                                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
                                                <button type="submit" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </section>
</div>

<!-- Modal Tambah Unit -->
<div class="modal fade" id="modal-tambah-unit" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="<?= site_url('alat/simpan_unit/' . $alat->id); ?>" method="post">
                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
                <div class="modal-header">
                    <h5 class="modal-title font-weight-bold">Tambah Unit Fisik Alat</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label>Nomor Inventaris <span class="text-danger">*</span></label>
                        <input type="text" name="nomor_inventaris" class="form-control" placeholder="Cth: INV/IPA/2026/001" required>
                    </div>
                    <div class="form-group">
                        <label>Nomor Seri Pabrik (Opsional)</label>
                        <input type="text" name="nomor_seri" class="form-control" placeholder="Cth: SN-8829102">
                    </div>
                    <div class="form-group">
                        <label>Penempatan Ruang Lab</label>
                        <select name="laboratorium_id" class="form-control">
                            <option value="">-- Pilih Ruang Lab --</option>
                            <?php foreach ($labs as $lab): ?>
                                <option value="<?= $lab->id; ?>"><?= html_escape($lab->nama); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Kondisi Awal</label>
                        <select name="kondisi" class="form-control">
                            <option value="baik">Baik</option>
                            <option value="rusak_ringan">Rusak Ringan</option>
                            <option value="rusak_berat">Rusak Berat</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Tanggal Perolehan</label>
                        <input type="date" name="tanggal_perolehan" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>Keterangan Tambahan</label>
                        <textarea name="keterangan" class="form-control" rows="2"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                    <button type="submit" class="btn btn-primary">Registrasi Unit</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $this->load->view('layout/footer'); ?>