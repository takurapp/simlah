<?php
$this->load->view('layout/header');
$this->load->view('layout/navbar');
$this->load->view('layout/sidebar');
?>

<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 font-weight-bold"><?= html_escape($judul); ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?= site_url('dashboard'); ?>">Home</a></li>
                        <li class="breadcrumb-item active">Laporan Mutasi Bahan</li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="container-fluid">

            <!-- Filter Panel -->
            <div class="card card-outline card-danger">
                <div class="card-header">
                    <h3 class="card-title font-weight-bold"><i class="fas fa-filter mr-1"></i> Filter Log Mutasi Bahan</h3>
                </div>
                <div class="card-body">
                    <form action="<?= site_url('laporan/bahan'); ?>" method="get">
                        <div class="row">
                            <div class="col-md-3 form-group">
                                <label>Dari Tanggal</label>
                                <input type="date" name="tgl_mulai" class="form-control" value="<?= html_escape($tgl_mulai); ?>">
                            </div>
                            <div class="col-md-3 form-group">
                                <label>Sampai Tanggal</label>
                                <input type="date" name="tgl_selesai" class="form-control" value="<?= html_escape($tgl_selesai); ?>">
                            </div>
                            <div class="col-md-3 form-group">
                                <label>Pilih Bahan</label>
                                <select name="bahan_id" class="form-control">
                                    <option value="">-- Semua Bahan --</option>
                                    <?php foreach ($bahan as $b): ?>
                                        <option value="<?= $b->id; ?>" <?= ($bahan_id == $b->id) ? 'selected' : ''; ?>>
                                            <?= html_escape($b->nama); ?> (<?= html_escape($b->kode); ?>)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-3 form-group">
                                <label>Jenis Mutasi</label>
                                <select name="jenis" class="form-control">
                                    <option value="">-- Semua Jenis --</option>
                                    <option value="masuk" <?= ($jenis === 'masuk') ? 'selected' : ''; ?>>Masuk (Pengadaan)</option>
                                    <option value="keluar" <?= ($jenis === 'keluar') ? 'selected' : ''; ?>>Keluar (Pemakaian)</option>
                                    <option value="penyesuaian" <?= ($jenis === 'penyesuaian') ? 'selected' : ''; ?>>Penyesuaian</option>
                                </select>
                            </div>
                        </div>
                        <div class="text-right">
                            <button type="submit" class="btn btn-danger btn-sm"><i class="fas fa-search mr-1"></i> Tampilkan</button>
                            <a href="<?= site_url('laporan/bahan'); ?>" class="btn btn-secondary btn-sm ml-1"><i class="fas fa-undo mr-1"></i> Reset</a>
                            <a href="<?= site_url('laporan/cetak_bahan?tgl_mulai=' . $tgl_mulai . '&tgl_selesai=' . $tgl_selesai . '&bahan_id=' . $bahan_id . '&jenis=' . $jenis); ?>" target="_blank" class="btn btn-success btn-sm ml-1">
                                <i class="fas fa-print mr-1"></i> Cetak Mutasi
                            </a>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Tabel Data Mutasi -->
            <div class="card card-outline card-secondary">
                <div class="card-header">
                    <h3 class="card-title font-weight-bold">Log Riwayat Mutasi Bahan Kimia / Reagen</h3>
                </div>
                <div class="card-body p-0 table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th style="width: 40px;">No</th>
                                <th>Tanggal & Waktu</th>
                                <th>Nama Bahan</th>
                                <th>No. Batch</th>
                                <th>Jenis</th>
                                <th>Jumlah</th>
                                <th>Keterangan / Alasan</th>
                                <th>Operator</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($laporan)): ?>
                                <tr>
                                    <td colspan="8" class="text-center text-muted py-3">Tidak ditemukan catatan mutasi pada rentang filter ini.</td>
                                </tr>
                            <?php else: ?>
                                <?php $no = 1;
                                foreach ($laporan as $row): ?>
                                    <tr>
                                        <td><?= $no++; ?></td>
                                        <td><?= date('d/m/Y H:i', strtotime($row->tanggal_transaksi)); ?></td>
                                        <td><strong><?= html_escape($row->nama_bahan); ?></strong></td>
                                        <td><?= html_escape($row->nomor_batch ?: '-'); ?></td>
                                        <td>
                                            <?php if ($row->jenis === 'masuk'): ?>
                                                <span class="badge badge-success">MASUK</span>
                                            <?php elseif ($row->jenis === 'keluar'): ?>
                                                <span class="badge badge-danger">KELUAR</span>
                                            <?php else: ?>
                                                <span class="badge badge-warning">PENYESUAIAN</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <strong><?= number_format((float)$row->jumlah, 2); ?></strong> <?= html_escape($row->satuan_simbol); ?>
                                        </td>
                                        <td><?= html_escape($row->alasan); ?></td>
                                        <td><?= html_escape($row->operator ?: '-'); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </section>
</div>

<?php $this->load->view('layout/footer'); ?>