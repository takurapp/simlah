<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="utf-8">
    <title>Laporan Peminjaman Alat IPA</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
            margin: 20px;
            color: #222;
        }

        .header {
            text-align: center;
            border-bottom: 2px solid #222;
            padding-bottom: 8px;
            margin-bottom: 16px;
        }

        .header h2 {
            margin: 0;
            font-size: 16px;
            text-transform: uppercase;
        }

        .header p {
            margin: 4px 0 0 0;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        th,
        td {
            border: 1px solid #333;
            padding: 6px 8px;
            text-align: left;
        }

        th {
            background: #f2f2f2;
            text-align: center;
        }

        @media print {
            .no-print {
                display: none;
            }

            body {
                margin: 0;
            }
        }
    </style>
</head>

<body>

    <div class="no-print" style="margin-bottom: 15px; text-align: right;">
        <button onclick="window.print()" style="padding: 6px 14px; background: #28a745; color: white; border: none; border-radius: 4px; cursor: pointer;">Print / Save PDF</button>
        <button onclick="window.close()" style="padding: 6px 14px; background: #6c757d; color: white; border: none; border-radius: 4px; cursor: pointer;">Tutup</button>
    </div>

    <div class="header">
        <h2>Sistem Informasi Manajemen Laboratorium IPA</h2>
        <p>Laporan Rekapitulasi Peminjaman Alat Praktikum</p>
        <small>Periode: <?= $tgl_mulai ? date('d/m/Y', strtotime($tgl_mulai)) : 'Awal'; ?> s.d. <?= $tgl_selesai ? date('d/m/Y', strtotime($tgl_selesai)) : 'Hari Ini'; ?></small>
    </div>

    <table>
        <thead>
            <tr>
                <th style="width: 30px;">No</th>
                <th>No. Registrasi</th>
                <th>Peminjam</th>
                <th>Ruang Lab</th>
                <th>Tgl Pinjam</th>
                <th>Tgl Kembali</th>
                <th>Jumlah</th>
                <th>Status</th>
                <th>Keperluan</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($laporan)): ?>
                <tr>
                    <td colspan="9" style="text-align: center;">Tidak ada data.</td>
                </tr>
            <?php else: ?>
                <?php $no = 1;
                foreach ($laporan as $r): ?>
                    <tr>
                        <td style="text-align: center;"><?= $no++; ?></td>
                        <td><?= html_escape($r->nomor_peminjaman); ?></td>
                        <td><?= html_escape($r->nama_peminjam); ?></td>
                        <td><?= html_escape($r->nama_lab ?: '-'); ?></td>
                        <td><?= date('d/m/Y H:i', strtotime($r->tanggal_pinjam)); ?></td>
                        <td><?= $r->tanggal_kembali ? date('d/m/Y H:i', strtotime($r->tanggal_kembali)) : '-'; ?></td>
                        <td style="text-align: center;"><?= $r->total_alat; ?></td>
                        <td style="text-align: center;"><?= ucfirst($r->status); ?></td>
                        <td><?= html_escape($r->keperluan); ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>

    <script>
        window.addEventListener('load', function() {
            window.print();
        });
    </script>
</body>

</html>