<?php
$this->load->view('layout/header');
$this->load->view('layout/navbar');
$this->load->view('layout/sidebar');
?>

<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 font-weight-bold"><?= html_escape($judul); ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?= site_url('dashboard'); ?>">Home</a></li>
                        <li class="breadcrumb-item active">Laporan Peminjaman</li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="container-fluid">

            <!-- Filter Panel -->
            <div class="card card-outline card-primary">
                <div class="card-header">
                    <h3 class="card-title font-weight-bold"><i class="fas fa-filter mr-1"></i> Filter Laporan</h3>
                </div>
                <div class="card-body">
                    <form action="<?= site_url('laporan/peminjaman'); ?>" method="get">
                        <div class="row">
                            <div class="col-md-3 form-group">
                                <label>Dari Tanggal</label>
                                <input type="date" name="tgl_mulai" class="form-control" value="<?= html_escape($tgl_mulai); ?>">
                            </div>
                            <div class="col-md-3 form-group">
                                <label>Sampai Tanggal</label>
                                <input type="date" name="tgl_selesai" class="form-control" value="<?= html_escape($tgl_selesai); ?>">
                            </div>
                            <div class="col-md-3 form-group">
                                <label>Ruang Laboratorium</label>
                                <select name="laboratorium_id" class="form-control">
                                    <option value="">-- Semua Lab --</option>
                                    <?php foreach ($laboratorium as $lab): ?>
                                        <option value="<?= $lab->id; ?>" <?= ($lab_id == $lab->id) ? 'selected' : ''; ?>>
                                            <?= html_escape($lab->nama); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-3 form-group">
                                <label>Status</label>
                                <select name="status" class="form-control">
                                    <option value="">-- Semua Status --</option>
                                    <option value="dipinjam" <?= ($status === 'dipinjam') ? 'selected' : ''; ?>>Dipinjam</option>
                                    <option value="selesai" <?= ($status === 'selesai') ? 'selected' : ''; ?>>Selesai</option>
                                </select>
                            </div>
                        </div>
                        <div class="text-right">
                            <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-search mr-1"></i> Tampilkan</button>
                            <a href="<?= site_url('laporan/peminjaman'); ?>" class="btn btn-secondary btn-sm ml-1"><i class="fas fa-undo mr-1"></i> Reset</a>
                            <a href="<?= site_url('laporan/cetak_peminjaman?tgl_mulai=' . $tgl_mulai . '&tgl_selesai=' . $tgl_selesai . '&laboratorium_id=' . $lab_id . '&status=' . $status); ?>" target="_blank" class="btn btn-success btn-sm ml-1">
                                <i class="fas fa-print mr-1"></i> Cetak Rekap
                            </a>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Tabel Data Laporan -->
            <div class="card card-outline card-secondary">
                <div class="card-header">
                    <h3 class="card-title font-weight-bold">Hasil Rekapitulasi Data</h3>
                </div>
                <div class="card-body p-0 table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th style="width: 40px;">No</th>
                                <th>No. Transaksi</th>
                                <th>Peminjam</th>
                                <th>Ruang Lab</th>
                                <th>Tanggal Pinjam</th>
                                <th>Tanggal Kembali</th>
                                <th>Total Alat</th>
                                <th>Status</th>
                                <th>Keperluan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($laporan)): ?>
                                <tr>
                                    <td colspan="9" class="text-center text-muted py-3">Tidak ditemukan data pada rentang filter ini.</td>
                                </tr>
                            <?php else: ?>
                                <?php $no = 1;
                                foreach ($laporan as $row): ?>
                                    <tr>
                                        <td><?= $no++; ?></td>
                                        <td><strong><?= html_escape($row->nomor_peminjaman); ?></strong></td>
                                        <td><?= html_escape($row->nama_peminjam); ?></td>
                                        <td><?= html_escape($row->nama_lab ?: '-'); ?></td>
                                        <td><?= date('d/m/Y H:i', strtotime($row->tanggal_pinjam)); ?></td>
                                        <td><?= $row->tanggal_kembali ? date('d/m/Y H:i', strtotime($row->tanggal_kembali)) : '-'; ?></td>
                                        <td><span class="badge badge-info"><?= $row->total_alat; ?> Unit</span></td>
                                        <td>
                                            <?php if ($row->status === 'selesai'): ?>
                                                <span class="badge badge-success">Selesai</span>
                                            <?php else: ?>
                                                <span class="badge badge-warning">Dipinjam</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?= html_escape($row->keperluan); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </section>
</div>

<?php $this->load->view('layout/footer'); ?>