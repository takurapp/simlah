<?php
$this->load->view('layout/header');
$this->load->view('layout/navbar');
$this->load->view('layout/sidebar');
?>

<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 font-weight-bold"><?= html_escape($judul); ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?= site_url('dashboard'); ?>">Home</a></li>
                        <li class="breadcrumb-item"><a href="<?= site_url('peminjaman'); ?>">Peminjaman</a></li>
                        <li class="breadcrumb-item active">Tambah</li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="container-fluid">

            <?= validation_errors('<div class="alert alert-danger"><i class="fas fa-exclamation-triangle mr-1"></i> ', '</div>'); ?>

            <form action="<?= site_url('peminjaman/simpan'); ?>" method="post">
                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">

                <div class="row">
                    <!-- Informasi Transaksi -->
                    <div class="col-md-5">
                        <div class="card card-outline card-primary">
                            <div class="card-header">
                                <h3 class="card-title font-weight-bold">Informasi Peminjaman</h3>
                            </div>
                            <div class="card-body">
                                <div class="form-group">
                                    <label for="user_id">Nama Peminjam <span class="text-danger">*</span></label>
                                    <select name="user_id" id="user_id" class="form-control" required>
                                        <option value="">-- Pilih Peminjam --</option>
                                        <?php foreach ($users as $u): ?>
                                            <option value="<?= $u->id; ?>" <?= set_select('user_id', $u->id, ($u->id == $this->session->userdata('user_id'))); ?>>
                                                <?= html_escape($u->nama_lengkap); ?> (<?= strtoupper(html_escape($u->role)); ?><?= $u->nomor_induk ? ' - ' . html_escape($u->nomor_induk) : ''; ?>)
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="laboratorium_id">Ruang Laboratorium Pelaksanaan <span class="text-danger">*</span></label>
                                    <select name="laboratorium_id" id="laboratorium_id" class="form-control" required>
                                        <option value="">-- Pilih Laboratorium --</option>
                                        <?php foreach ($laboratorium as $lab): ?>
                                            <option value="<?= $lab->id; ?>" <?= set_select('laboratorium_id', $lab->id); ?>>
                                                <?= html_escape($lab->nama); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label for="tanggal_pinjam">Tanggal Pinjam <span class="text-danger">*</span></label>
                                        <input type="datetime-local" id="tanggal_pinjam" name="tanggal_pinjam" class="form-control" value="<?= set_value('tanggal_pinjam', date('Y-m-d\TH:i')); ?>" required>
                                    </div>
                                    <div class="col-md-6 form-group">
                                        <label for="rencana_kembali">Rencana Kembali <span class="text-danger">*</span></label>
                                        <input type="datetime-local" id="rencana_kembali" name="rencana_kembali" class="form-control" value="<?= set_value('rencana_kembali', date('Y-m-d\TH:i', strtotime('+3 hours'))); ?>" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="keperluan">Keperluan / Topik Praktikum <span class="text-danger">*</span></label>
                                    <textarea id="keperluan" name="keperluan" class="form-control" rows="3" placeholder="Cth: Pengamatan Sel Bawang Merah Siswa Kelas VII-B" required><?= set_value('keperluan'); ?></textarea>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Checklist Unit Alat -->
                    <div class="col-md-7">
                        <div class="card card-outline card-success">
                            <div class="card-header">
                                <h3 class="card-title font-weight-bold">Pilih Unit Alat yang Tersedia</h3>
                            </div>
                            <div class="card-body p-0 table-responsive" style="max-height: 460px;">
                                <table class="table table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th style="width: 40px;" class="text-center">Pilih</th>
                                            <th>No. Inventaris</th>
                                            <th>Nama Alat</th>
                                            <th>Kondisi</th>
                                            <th>Asal Lab</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (empty($unit_tersedia)): ?>
                                            <tr>
                                                <td colspan="5" class="text-center text-muted py-4">Semua unit alat sedang dipinjam atau dalam perbaikan.</td>
                                            </tr>
                                        <?php else: ?>
                                            <?php foreach ($unit_tersedia as $u): ?>
                                                <tr>
                                                    <td class="text-center">
                                                        <div class="custom-control custom-checkbox">
                                                            <input class="custom-control-input" type="checkbox" name="unit_alat_id[]" id="chk_<?= $u->id; ?>" value="<?= $u->id; ?>">
                                                            <label for="chk_<?= $u->id; ?>" class="custom-control-label"></label>
                                                        </div>
                                                    </td>
                                                    <td><strong><?= html_escape($u->nomor_inventaris); ?></strong></td>
                                                    <td>
                                                        <?= html_escape($u->nama_alat); ?><br>
                                                        <small class="text-muted"><?= html_escape($u->merek ?: 'Tanpa Merek'); ?></small>
                                                    </td>
                                                    <td><span class="badge badge-success"><?= ucfirst($u->kondisi); ?></span></td>
                                                    <td><?= html_escape($u->nama_lab ?: 'Gudang Utama'); ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane mr-1"></i> Ajukan Peminjaman</button>
                                <a href="<?= site_url('peminjaman'); ?>" class="btn btn-secondary ml-2"><i class="fas fa-arrow-left mr-1"></i> Batal</a>
                            </div>
                        </div>
                    </div>
                </div>
            </form>

        </div>
    </section>
</div>

<?php $this->load->view('layout/footer'); ?>