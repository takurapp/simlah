<?php
$this->load->view('layout/header');
$this->load->view('layout/navbar');
$this->load->view('layout/sidebar');
?>

<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 font-weight-bold">Detail Peminjaman Alat</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?= site_url('dashboard'); ?>">Home</a></li>
                        <li class="breadcrumb-item"><a href="<?= site_url('peminjaman'); ?>">Peminjaman</a></li>
                        <li class="breadcrumb-item active">Detail</li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="container-fluid">

            <?php if ($this->session->flashdata('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="icon fas fa-check mr-1"></i> <?= html_escape($this->session->flashdata('success')); ?>
                    <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span></button>
                </div>
            <?php endif; ?>

            <?php if ($this->session->flashdata('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="icon fas fa-ban mr-1"></i> <?= html_escape($this->session->flashdata('error')); ?>
                    <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span></button>
                </div>
            <?php endif; ?>

            <!-- Informasi Peminjaman -->
            <div class="card card-outline card-info">
                <div class="card-header">
                    <h3 class="card-title font-weight-bold"><i class="fas fa-file-invoice mr-1"></i> No. Registrasi: <?= html_escape($pinjam->nomor_peminjaman); ?></h3>
                    <div class="card-tools">
                        <a href="<?= site_url('peminjaman/cetak/' . $pinjam->id); ?>" target="_blank" class="btn btn-default btn-sm mr-1">
                            <i class="fas fa-print mr-1"></i> Cetak Bukti
                        </a>
                        <a href="<?= site_url('peminjaman'); ?>" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left mr-1"></i> Kembali</a>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-3"><strong>Peminjam:</strong><br><?= html_escape($pinjam->nama_peminjam); ?></div>
                        <div class="col-md-3"><strong>Ruang Lab:</strong><br><?= html_escape($pinjam->nama_lab ?: '-'); ?></div>
                        <div class="col-md-3"><strong>Waktu Pinjam:</strong><br><?= date('d/m/Y H:i', strtotime($pinjam->tanggal_pinjam)); ?></div>
                        <div class="col-md-3">
                            <strong>Status:</strong><br>
                            <?php if ($pinjam->status === 'selesai'): ?>
                                <span class="badge badge-success p-2">Selesai (Dikembalikan)</span>
                            <?php else: ?>
                                <span class="badge badge-warning p-2">Sedang Dipinjam</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-md-6"><strong>Keperluan:</strong><br><?= html_escape($pinjam->keperluan); ?></div>
                        <div class="col-md-6"><strong>Petugas Verifikator:</strong><br><?= html_escape($pinjam->nama_petugas ?: 'Belum diverifikasi'); ?></div>
                    </div>
                </div>
            </div>

            <!-- Daftar Alat yang Dipinjam & Form Pengembalian -->
            <div class="card card-outline card-primary">
                <div class="card-header">
                    <h3 class="card-title font-weight-bold">Daftar Unit Alat Terpinjam</h3>
                </div>

                <?php if ($pinjam->status === 'dipinjam' && in_array($this->session->userdata('role'), array('admin', 'laboran'))): ?>
                    <form action="<?= site_url('peminjaman/proses_kembali/' . $pinjam->id); ?>" method="post">
                        <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
                    <?php endif; ?>

                    <div class="card-body p-0 table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th style="width: 40px;">No</th>
                                    <th>No. Inventaris</th>
                                    <th>Nama Alat</th>
                                    <th>Kondisi Saat Keluar</th>
                                    <th style="width: 200px;">Kondisi Saat Kembali</th>
                                    <th>Catatan Kerusakan/Keterangan</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $no = 1;
                                foreach ($items as $item): ?>
                                    <tr>
                                        <td><?= $no++; ?></td>
                                        <td><strong><?= html_escape($item->nomor_inventaris); ?></strong></td>
                                        <td><?= html_escape($item->nama_alat); ?> (<?= html_escape($item->merek ?: '-'); ?>)</td>
                                        <td><span class="badge badge-secondary"><?= ucfirst($item->kondisi_keluar); ?></span></td>
                                        <td>
                                            <?php if ($pinjam->status === 'selesai'): ?>
                                                <span class="badge badge-info"><?= ucfirst($item->kondisi_kembali ?: '-'); ?></span>
                                            <?php else: ?>
                                                <select name="kondisi_kembali[<?= $item->id; ?>]" class="form-control form-control-sm">
                                                    <option value="baik">Baik</option>
                                                    <option value="rusak_ringan">Rusak Ringan</option>
                                                    <option value="rusak_berat">Rusak Berat</option>
                                                </select>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($pinjam->status === 'selesai'): ?>
                                                <?= html_escape($item->catatan ?: '-'); ?>
                                            <?php else: ?>
                                                <input type="text" name="catatan[<?= $item->id; ?>]" class="form-control form-control-sm" placeholder="Catatan kondisi fisik (opsional)">
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                    <?php if ($pinjam->status === 'dipinjam' && in_array($this->session->userdata('role'), array('admin', 'laboran'))): ?>
                        <div class="card-footer text-right">
                            <button type="submit" class="btn btn-success" onclick="return confirm('Konfirmasi bahwa semua alat di atas telah diperiksa dan dikembalikan ke laboratorium?');">
                                <i class="fas fa-check-circle mr-1"></i> Verifikasi Pengembalian Alat
                            </button>
                        </div>
                    </form>
                <?php endif; ?>
            </div>

        </div>
    </section>
</div>

<?php $this->load->view('layout/footer'); ?>