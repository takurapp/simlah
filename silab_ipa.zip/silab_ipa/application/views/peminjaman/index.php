<?php
$this->load->view('layout/header');
$this->load->view('layout/navbar');
$this->load->view('layout/sidebar');
?>

<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 font-weight-bold"><?= html_escape($judul); ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?= site_url('dashboard'); ?>">Home</a></li>
                        <li class="breadcrumb-item active">Peminjaman</li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="container-fluid">

            <?php if ($this->session->flashdata('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="icon fas fa-check mr-1"></i> <?= html_escape($this->session->flashdata('success')); ?>
                    <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span></button>
                </div>
            <?php endif; ?>

            <?php if ($this->session->flashdata('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="icon fas fa-ban mr-1"></i> <?= html_escape($this->session->flashdata('error')); ?>
                    <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span></button>
                </div>
            <?php endif; ?>

            <div class="card card-outline card-primary">
                <div class="card-header">
                    <h3 class="card-title font-weight-bold">Data Peminjaman Alat Praktikum</h3>
                    <div class="card-tools">
                        <a href="<?= site_url('peminjaman/tambah'); ?>" class="btn btn-primary btn-sm">
                            <i class="fas fa-plus mr-1"></i> Pinjam Alat Baru
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th style="width: 40px;">No</th>
                                <th>No. Transaksi</th>
                                <th>Peminjam</th>
                                <th>Ruang Lab</th>
                                <th>Tgl Pinjam</th>
                                <th>Batas Kembali</th>
                                <th>Jumlah Item</th>
                                <th>Status</th>
                                <th style="width: 90px;" class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($peminjaman)): ?>
                                <tr>
                                    <td colspan="9" class="text-center text-muted">Belum ada riwayat transaksi peminjaman.</td>
                                </tr>
                            <?php else: ?>
                                <?php $no = 1;
                                foreach ($peminjaman as $p): ?>
                                    <tr>
                                        <td><?= $no++; ?></td>
                                        <td><strong><?= html_escape($p->nomor_peminjaman); ?></strong></td>
                                        <td><?= html_escape($p->nama_peminjam); ?></td>
                                        <td><?= html_escape($p->nama_lab ?: '-'); ?></td>
                                        <td><?= date('d/m/Y H:i', strtotime($p->tanggal_pinjam)); ?></td>
                                        <td><?= date('d/m/Y H:i', strtotime($p->rencana_kembali)); ?></td>
                                        <td><span class="badge badge-info"><?= $p->total_alat; ?> Unit</span></td>
                                        <td>
                                            <?php if ($p->status === 'selesai'): ?>
                                                <span class="badge badge-success">Selesai</span>
                                            <?php elseif ($p->status === 'dipinjam'): ?>
                                                <span class="badge badge-warning">Sedang Dipinjam</span>
                                            <?php else: ?>
                                                <span class="badge badge-secondary"><?= ucfirst($p->status); ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center">
                                            <a href="<?= site_url('peminjaman/detail/' . $p->id); ?>" class="btn btn-info btn-sm">
                                                <i class="fas fa-eye mr-1"></i> Detail
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </section>
</div>

<?php $this->load->view('layout/footer'); ?>