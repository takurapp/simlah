<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="utf-8">
    <title>Bukti Peminjaman - <?= html_escape($pinjam->nomor_peminjaman); ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            color: #333;
            margin: 0;
            padding: 20px;
            font-size: 13px;
        }

        .header {
            text-align: center;
            border-bottom: 2px solid #333;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }

        .header h2 {
            margin: 0;
            text-transform: uppercase;
            font-size: 18px;
        }

        .header p {
            margin: 4px 0 0 0;
            font-size: 12px;
        }

        .meta-table {
            width: 100%;
            margin-bottom: 20px;
        }

        .meta-table td {
            padding: 4px;
            vertical-align: top;
        }

        .item-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }

        .item-table th,
        .item-table td {
            border: 1px solid #333;
            padding: 8px;
            text-align: left;
        }

        .item-table th {
            background-color: #f2f2f2;
        }

        .signatures {
            width: 100%;
            margin-top: 40px;
        }

        .signatures td {
            text-align: center;
            vertical-align: top;
            width: 50%;
        }

        .sign-space {
            height: 70px;
        }

        .badge {
            font-weight: bold;
            text-transform: uppercase;
        }

        @media print {
            .no-print {
                display: none;
            }

            body {
                padding: 0;
            }
        }
    </style>
</head>

<body>

    <div class="no-print" style="margin-bottom: 15px; text-align: right;">
        <button onclick="window.print()" style="padding: 8px 16px; background: #28a745; color: white; border: none; border-radius: 4px; cursor: pointer;">
            Cetak / Simpan PDF
        </button>
        <button onclick="window.close()" style="padding: 8px 16px; background: #6c757d; color: white; border: none; border-radius: 4px; cursor: pointer; margin-left: 6px;">
            Tutup
        </button>
    </div>

    <div class="header">
        <h2>Sistem Informasi Manajemen Laboratorium IPA</h2>
        <p>Formulir Bukti Peminjaman dan Pengembalian Alat Praktikum</p>
    </div>

    <table class="meta-table">
        <tr>
            <td style="width: 20%;"><strong>No. Transaksi</strong></td>
            <td style="width: 30%;">: <?= html_escape($pinjam->nomor_peminjaman); ?></td>
            <td style="width: 20%;"><strong>Tanggal Pinjam</strong></td>
            <td style="width: 30%;">: <?= date('d/m/Y H:i', strtotime($pinjam->tanggal_pinjam)); ?></td>
        </tr>
        <tr>
            <td><strong>Nama Peminjam</strong></td>
            <td>: <?= html_escape($pinjam->nama_peminjam); ?></td>
            <td><strong>Rencana Kembali</strong></td>
            <td>: <?= date('d/m/Y H:i', strtotime($pinjam->rencana_kembali)); ?></td>
        </tr>
        <tr>
            <td><strong>Ruang Lab</strong></td>
            <td>: <?= html_escape($pinjam->nama_lab ?: '-'); ?></td>
            <td><strong>Tanggal Selesai</strong></td>
            <td>: <?= $pinjam->tanggal_kembali ? date('d/m/Y H:i', strtotime($pinjam->tanggal_kembali)) : 'Belum Dikembalikan'; ?></td>
        </tr>
        <tr>
            <td><strong>Keperluan</strong></td>
            <td colspan="3">: <?= html_escape($pinjam->keperluan); ?></td>
        </tr>
    </table>

    <table class="item-table">
        <thead>
            <tr>
                <th style="width: 30px; text-align: center;">No</th>
                <th>Nomor Inventaris</th>
                <th>Nama Alat & Spesifikasi</th>
                <th style="width: 120px;">Kondisi Keluar</th>
                <th style="width: 120px;">Kondisi Kembali</th>
                <th>Catatan</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 1;
            foreach ($items as $item): ?>
                <tr>
                    <td style="text-align: center;"><?= $no++; ?></td>
                    <td><strong><?= html_escape($item->nomor_inventaris); ?></strong></td>
                    <td>
                        <?= html_escape($item->nama_alat); ?>
                        <?= $item->merek ? '(' . html_escape($item->merek) . ')' : ''; ?>
                    </td>
                    <td><?= ucfirst(html_escape($item->kondisi_keluar)); ?></td>
                    <td><?= $item->kondisi_kembali ? ucfirst(html_escape($item->kondisi_kembali)) : '-'; ?></td>
                    <td><?= html_escape($item->catatan ?: '-'); ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <table class="signatures">
        <tr>
            <td>
                Petugas Laboran / Verifikator,
                <div class="sign-space"></div>
                <strong>( <?= html_escape($pinjam->nama_petugas ?: '..........................................'); ?> )</strong>
            </td>
            <td>
                Guru / Peminjam,
                <div class="sign-space"></div>
                <strong>( <?= html_escape($pinjam->nama_peminjam); ?> )</strong>
            </td>
        </tr>
    </table>

    <script>
        window.addEventListener('load', function() {
            window.print();
        });
    </script>
</body>

</html>