<?php
$this->load->view('layout/header');
$this->load->view('layout/navbar');
$this->load->view('layout/sidebar');
?>

<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1><?= html_escape($judul); ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?= site_url('dashboard'); ?>">Home</a></li>
                        <li class="breadcrumb-item"><a href="<?= site_url('laboratorium'); ?>">Laboratorium</a></li>
                        <li class="breadcrumb-item active">Edit</li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-8">
                    <div class="card card-warning">
                        <div class="card-header">
                            <h3 class="card-title text-white">Form Edit Ruang Laboratorium</h3>
                        </div>

                        <?= validation_errors('<div class="alert alert-danger m-3"><i class="fas fa-exclamation-triangle mr-1"></i> ', '</div>'); ?>

                        <form action="<?= site_url('laboratorium/update/' . $lab->id); ?>" method="post">
                            <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">

                            <div class="card-body">
                                <div class="form-group">
                                    <label for="kode">Kode Laboratorium <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="kode" name="kode" value="<?= set_value('kode', $lab->kode); ?>" required>
                                </div>

                                <div class="form-group">
                                    <label for="nama">Nama Laboratorium <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="nama" name="nama" value="<?= set_value('nama', $lab->nama); ?>" required>
                                </div>

                                <div class="form-group">
                                    <label for="lokasi">Lokasi / Gedung</label>
                                    <input type="text" class="form-control" id="lokasi" name="lokasi" value="<?= set_value('lokasi', $lab->lokasi); ?>">
                                </div>

                                <div class="form-group">
                                    <label for="kapasitas">Kapasitas (Siswa)</label>
                                    <input type="number" class="form-control" id="kapasitas" name="kapasitas" value="<?= set_value('kapasitas', $lab->kapasitas); ?>" min="1">
                                </div>

                                <div class="form-group">
                                    <label for="keterangan">Keterangan</label>
                                    <textarea class="form-control" id="keterangan" name="keterangan" rows="3"><?= set_value('keterangan', $lab->keterangan); ?></textarea>
                                </div>

                                <div class="form-group">
                                    <div class="custom-control custom-switch">
                                        <input type="checkbox" class="custom-control-input" id="aktifSwitch" name="aktif" value="1" <?= set_checkbox('aktif', '1', (bool) $lab->aktif); ?>>
                                        <label class="custom-control-label" for="aktifSwitch">Status Aktif</label>
                                    </div>
                                </div>
                            </div>

                            <div class="card-footer">
                                <button type="submit" class="btn btn-warning text-white"><i class="fas fa-save mr-1"></i> Perbarui</button>
                                <a href="<?= site_url('laboratorium'); ?>" class="btn btn-secondary ml-2"><i class="fas fa-arrow-left mr-1"></i> Batal</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<?php $this->load->view('layout/footer'); ?>