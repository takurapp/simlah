<?php
$this->load->view('layout/header');
$this->load->view('layout/navbar');
$this->load->view('layout/sidebar');
?>

<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 font-weight-bold"><?= html_escape($judul); ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?= site_url('dashboard'); ?>">Home</a></li>
                        <li class="breadcrumb-item active">Pengguna</li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="container-fluid">

            <?php if ($this->session->flashdata('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="icon fas fa-check mr-1"></i> <?= html_escape($this->session->flashdata('success')); ?>
                    <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span></button>
                </div>
            <?php endif; ?>

            <?php if ($this->session->flashdata('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="icon fas fa-ban mr-1"></i> <?= html_escape($this->session->flashdata('error')); ?>
                    <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span></button>
                </div>
            <?php endif; ?>

            <div class="card card-outline card-primary">
                <div class="card-header">
                    <h3 class="card-title font-weight-bold">Daftar Akun Pengguna SILAB IPA</h3>
                    <div class="card-tools">
                        <a href="<?= site_url('users/create'); ?>" class="btn btn-primary btn-sm">
                            <i class="fas fa-user-plus mr-1"></i> Tambah Pengguna
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th style="width: 40px;">No</th>
                                <th>Nama Lengkap</th>
                                <th>NIP / NUPTK</th>
                                <th>Username</th>
                                <th>Peran</th>
                                <th>No. Telepon</th>
                                <th>Status</th>
                                <th style="width: 140px;" class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($users)): ?>
                                <tr>
                                    <td colspan="8" class="text-center text-muted">Belum ada akun pengguna.</td>
                                </tr>
                            <?php else: ?>
                                <?php $no = 1;
                                foreach ($users as $u): ?>
                                    <tr>
                                        <td><?= $no++; ?></td>
                                        <td><strong><?= html_escape($u->nama_lengkap); ?></strong></td>
                                        <td><?= html_escape($u->nomor_induk ?: '-'); ?></td>
                                        <td><code><?= html_escape($u->username); ?></code></td>
                                        <td>
                                            <?php if ($u->role === 'admin'): ?>
                                                <span class="badge badge-danger">ADMIN</span>
                                            <?php elseif ($u->role === 'laboran'): ?>
                                                <span class="badge badge-info">LABORAN</span>
                                            <?php else: ?>
                                                <span class="badge badge-success">GURU</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?= html_escape($u->nomor_telepon ?: '-'); ?></td>
                                        <td>
                                            <?php if ($u->aktif): ?>
                                                <span class="badge badge-success">Aktif</span>
                                            <?php else: ?>
                                                <span class="badge badge-secondary">Nonaktif</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center">
                                            <a href="<?= site_url('users/edit/' . $u->id); ?>" class="btn btn-warning btn-sm text-white" title="Edit Akun">
                                                <i class="fas fa-edit"></i>
                                            </a>

                                            <?php if ((int)$u->id !== (int)$this->session->userdata('user_id')): ?>
                                                <form action="<?= site_url('users/toggle_status/' . $u->id); ?>" method="post" class="d-inline" onsubmit="return confirm('Ubah status aktif akun ini?');">
                                                    <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
                                                    <?php if ($u->aktif): ?>
                                                        <button type="submit" class="btn btn-secondary btn-sm" title="Nonaktifkan Akun">
                                                            <i class="fas fa-user-slash"></i>
                                                        </button>
                                                    <?php else: ?>
                                                        <button type="submit" class="btn btn-success btn-sm" title="Aktifkan Akun">
                                                            <i class="fas fa-user-check"></i>
                                                        </button>
                                                    <?php endif; ?>
                                                </form>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </section>
</div>

<?php $this->load->view('layout/footer'); ?>