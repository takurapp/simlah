<?php
$this->load->view('layout/header');
$this->load->view('layout/navbar');
$this->load->view('layout/sidebar');

$is_edit = ($aksi !== 'create');
$val_nama = $is_edit ? $user->nama_lengkap : '';
$val_nip  = $is_edit ? $user->nomor_induk : '';
$val_user = $is_edit ? $user->username : '';
$val_role = $is_edit ? $user->role : 'guru';
$val_telp = $is_edit ? $user->nomor_telepon : '';
?>

<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 font-weight-bold"><?= html_escape($judul); ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?= site_url('dashboard'); ?>">Home</a></li>
                        <li class="breadcrumb-item"><a href="<?= site_url('users'); ?>">Pengguna</a></li>
                        <li class="breadcrumb-item active"><?= $is_edit ? 'Edit' : 'Tambah'; ?></li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-8">
                    <div class="card <?= $is_edit ? 'card-warning' : 'card-primary'; ?>">
                        <div class="card-header">
                            <h3 class="card-title font-weight-bold <?= $is_edit ? 'text-white' : ''; ?>">
                                <?= $is_edit ? 'Form Perbarui Akun Pengguna' : 'Form Registrasi Akun Pengguna'; ?>
                            </h3>
                        </div>

                        <?php if ($this->session->flashdata('error')): ?>
                            <div class="alert alert-danger m-3">
                                <i class="fas fa-ban mr-1"></i> <?= html_escape($this->session->flashdata('error')); ?>
                            </div>
                        <?php endif; ?>

                        <?= validation_errors('<div class="alert alert-danger m-3"><i class="fas fa-exclamation-triangle mr-1"></i> ', '</div>'); ?>

                        <form action="<?= site_url('users/' . $aksi); ?>" method="post">
                            <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">

                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label for="nama_lengkap">Nama Lengkap <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="nama_lengkap" name="nama_lengkap" value="<?= set_value('nama_lengkap', $val_nama); ?>" placeholder="Cth: Dr. Ahmad Fauzi, M.Pd" required>
                                    </div>
                                    <div class="col-md-6 form-group">
                                        <label for="nomor_induk">Nomor Induk (NIP / NUPTK)</label>
                                        <input type="text" class="form-control" id="nomor_induk" name="nomor_induk" value="<?= set_value('nomor_induk', $val_nip); ?>" placeholder="Cth: 198501012010011001">
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label for="username">Username Login <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="username" name="username" value="<?= set_value('username', $val_user); ?>" placeholder="Hanya huruf dan angka" required>
                                    </div>
                                    <div class="col-md-6 form-group">
                                        <label for="password">Password <?= $is_edit ? '<small class="text-muted">(Kosongkan jika tidak diganti)</small>' : '<span class="text-danger">* (Min. 12 Karakter)</span>'; ?></label>
                                        <input type="password" class="form-control" id="password" name="password" placeholder="Minimal 12 karakter" <?= $is_edit ? '' : 'required'; ?>>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label for="role">Peran (Role) <span class="text-danger">*</span></label>
                                        <select class="form-control" id="role" name="role" required>
                                            <option value="guru" <?= set_select('role', 'guru', ($val_role === 'guru')); ?>>Guru</option>
                                            <option value="laboran" <?= set_select('role', 'laboran', ($val_role === 'laboran')); ?>>Laboran</option>
                                            <option value="admin" <?= set_select('role', 'admin', ($val_role === 'admin')); ?>>Admin</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6 form-group">
                                        <label for="nomor_telepon">Nomor WhatsApp / Telepon</label>
                                        <input type="text" class="form-control" id="nomor_telepon" name="nomor_telepon" value="<?= set_value('nomor_telepon', $val_telp); ?>" placeholder="Cth: 081234567890">
                                    </div>
                                </div>
                            </div>

                            <div class="card-footer">
                                <button type="submit" class="btn <?= $is_edit ? 'btn-warning text-white' : 'btn-primary'; ?>">
                                    <i class="fas fa-save mr-1"></i> <?= $is_edit ? 'Perbarui Data' : 'Simpan Pengguna'; ?>
                                </button>
                                <a href="<?= site_url('users'); ?>" class="btn btn-secondary ml-2">
                                    <i class="fas fa-arrow-left mr-1"></i> Batal
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<?php $this->load->view('layout/footer'); ?>