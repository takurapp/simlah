<?php
$this->load->view('layout/header');
$this->load->view('layout/navbar');
$this->load->view('layout/sidebar');
?>

<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 font-weight-bold"><?= html_escape($judul); ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?= site_url('dashboard'); ?>">Home</a></li>
                        <li class="breadcrumb-item"><a href="<?= site_url('users'); ?>">Pengguna</a></li>
                        <li class="breadcrumb-item active">Tambah</li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-8">
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title font-weight-bold">Form Registrasi Akun Pengguna</h3>
                        </div>

                        <?= validation_errors('<div class="alert alert-danger m-3"><i class="fas fa-exclamation-triangle mr-1"></i> ', '</div>'); ?>

                        <form action="<?= site_url('users/simpan'); ?>" method="post">
                            <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">

                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label for="nama_lengkap">Nama Lengkap <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="nama_lengkap" name="nama_lengkap" value="<?= set_value('nama_lengkap'); ?>" placeholder="Cth: Dr. Ahmad Fauzi, M.Pd" required>
                                    </div>
                                    <div class="col-md-6 form-group">
                                        <label for="nomor_induk">Nomor Induk (NIP / NUPTK)</label>
                                        <input type="text" class="form-control" id="nomor_induk" name="nomor_induk" value="<?= set_value('nomor_induk'); ?>" placeholder="Cth: 198501012010011001">
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label for="username">Username Login <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="username" name="username" value="<?= set_value('username'); ?>" placeholder="Cth: ahmadfauzi" required>
                                    </div>
                                    <div class="col-md-6 form-group">
                                        <label for="password">Password <span class="text-danger">*</span></label>
                                        <input type="password" class="form-control" id="password" name="password" placeholder="Minimal 6 karakter" required>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label for="role">Hak Akses (Role) <span class="text-danger">*</span></label>
                                        <select class="form-control" id="role" name="role" required>
                                            <option value="guru" <?= set_select('role', 'guru', true); ?>>Guru</option>
                                            <option value="laboran" <?= set_select('role', 'laboran'); ?>>Laboran</option>
                                            <option value="admin" <?= set_select('role', 'admin'); ?>>Admin Laboratorium</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6 form-group">
                                        <label for="nomor_telepon">Nomor WhatsApp / Telepon</label>
                                        <input type="text" class="form-control" id="nomor_telepon" name="nomor_telepon" value="<?= set_value('nomor_telepon'); ?>" placeholder="Cth: 081234567890">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="custom-control custom-switch">
                                        <input type="checkbox" class="custom-control-input" id="aktifSwitch" name="aktif" value="1" <?= set_checkbox('aktif', '1', true); ?>>
                                        <label class="custom-control-label" for="aktifSwitch">Akun Aktif</label>
                                    </div>
                                </div>
                            </div>

                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary"><i class="fas fa-save mr-1"></i> Simpan Pengguna</button>
                                <a href="<?= site_url('users'); ?>" class="btn btn-secondary ml-2"><i class="fas fa-arrow-left mr-1"></i> Kembali</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<?php $this->load->view('layout/footer'); ?>