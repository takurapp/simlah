<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login SIM LAB IPA</title>
    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #eef2f7;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .login-box {
            width: 360px;
            max-width: calc(100% - 32px);
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 20px #00000012;
        }

        h2 {
            color: #243b64;
            text-align: center;
        }

        p {
            color: #666;
            text-align: center;
        }

        label {
            display: block;
            margin-top: 16px;
        }

        input {
            width: 100%;
            padding: 11px;
            margin-top: 6px;
            border: 1px solid #ccd2da;
            border-radius: 5px;
        }

        button {
            width: 100%;
            margin-top: 22px;
            padding: 12px;
            border: 0;
            border-radius: 5px;
            background: #243b64;
            color: white;
            cursor: pointer;
        }

        .error {
            padding: 10px;
            background: #f8d7da;
            color: #842029;
            border-radius: 5px;
        }
    </style>
</head>

<body>
    <div class="login-box">
        <h2>SIM LAB IPA</h2>
        <p>Silakan masuk ke aplikasi</p>

        <?php if ($this->session->flashdata('error')): ?>
            <div class="error">
                <?= html_escape($this->session->flashdata('error')); ?>
            </div>
        <?php endif; ?>

        <?= validation_errors('<div class="error">', '</div>'); ?>

        <form action="<?= site_url('auth/login'); ?>" method="post">
            <input type="hidden"
                name="<?= $this->security->get_csrf_token_name(); ?>"
                value="<?= $this->security->get_csrf_hash(); ?>">

            <label for="username">Username</label>
            <input type="text" id="username" name="username"
                value="<?= set_value('username'); ?>"
                autocomplete="username" required autofocus>

            <label for="password">Password</label>
            <input type="password" id="password" name="password"
                autocomplete="current-password" required>

            <button type="submit">Login</button>
        </form>
    </div>
</body>

</html>