<?php
$this->load->view('layout/header');
$this->load->view('layout/navbar');
$this->load->view('layout/sidebar');
?>

<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 font-weight-bold"><?= html_escape($judul); ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?= site_url('dashboard'); ?>">Home</a></li>
                        <li class="breadcrumb-item active">Bahan</li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="container-fluid">

            <?php if ($this->session->flashdata('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="icon fas fa-check mr-1"></i> <?= html_escape($this->session->flashdata('success')); ?>
                    <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span></button>
                </div>
            <?php endif; ?>

            <?php if ($this->session->flashdata('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="icon fas fa-ban mr-1"></i> <?= html_escape($this->session->flashdata('error')); ?>
                    <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span></button>
                </div>
            <?php endif; ?>

            <div class="card card-outline card-danger">
                <div class="card-header">
                    <h3 class="card-title font-weight-bold">Daftar Bahan & Reagen Laboratorium</h3>
                    <div class="card-tools">
                        <button type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#modal-tambah-bahan">
                            <i class="fas fa-plus mr-1"></i> Tambah Master Bahan
                        </button>
                    </div>
                </div>
                <div class="card-body">
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th style="width: 40px;">No</th>
                                <th>Kode</th>
                                <th>Nama Bahan</th>
                                <th>Rumus / CAS</th>
                                <th>Kategori</th>
                                <th>Jenis Bahaya</th>
                                <th>Total Stok</th>
                                <th style="width: 140px;" class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($bahan)): ?>
                                <tr>
                                    <td colspan="8" class="text-center text-muted">Belum ada katalog bahan.</td>
                                </tr>
                            <?php else: ?>
                                <?php $no = 1;
                                foreach ($bahan as $item): ?>
                                    <tr>
                                        <td><?= $no++; ?></td>
                                        <td><span class="badge badge-secondary"><?= html_escape($item->kode); ?></span></td>
                                        <td><strong><?= html_escape($item->nama); ?></strong></td>
                                        <td>
                                            <?= html_escape($item->rumus_kimia ?: '-'); ?><br>
                                            <small class="text-muted">CAS: <?= html_escape($item->nomor_cas ?: '-'); ?></small>
                                        </td>
                                        <td><?= html_escape($item->kategori_nama ?: '-'); ?></td>
                                        <td>
                                            <?php if ($item->jenis_bahaya): ?>
                                                <span class="badge badge-danger"><?= html_escape($item->jenis_bahaya); ?></span>
                                            <?php else: ?>
                                                <span class="text-muted">-</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ((float)$item->total_stok <= (float)$item->stok_minimum): ?>
                                                <span class="badge badge-warning p-2">
                                                    <?= number_format((float)$item->total_stok, 2); ?> <?= html_escape($item->satuan_simbol); ?> (Menipis)
                                                </span>
                                            <?php else: ?>
                                                <span class="badge badge-success p-2">
                                                    <?= number_format((float)$item->total_stok, 2); ?> <?= html_escape($item->satuan_simbol); ?>
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center">
                                            <a href="<?= site_url('bahan/detail/' . $item->id); ?>" class="btn btn-primary btn-sm" title="Kelola Batch & Stok">
                                                <i class="fas fa-layer-group"></i> Batch
                                            </a>
                                            <a href="<?= site_url('bahan/edit/' . $item->id); ?>" class="btn btn-warning btn-sm text-white" title="Edit Master Bahan">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <form action="<?= site_url('bahan/hapus/' . $item->id); ?>" method="post" class="d-inline" onsubmit="return confirm('Hapus master bahan ini?');">
                                                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
                                                <button type="submit" class="btn btn-danger btn-sm" title="Hapus"><i class="fas fa-trash"></i></button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </section>
</div>

<!-- Modal Tambah Master Bahan -->
<div class="modal fade" id="modal-tambah-bahan" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form action="<?= site_url('bahan/simpan'); ?>" method="post">
                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
                <div class="modal-header">
                    <h5 class="modal-title font-weight-bold">Tambah Katalog Bahan Kimia</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 form-group">
                            <label>Kode Bahan <span class="text-danger">*</span></label>
                            <input type="text" name="kode" class="form-control" placeholder="Cth: MAT-HCL-01" required>
                        </div>
                        <div class="col-md-6 form-group">
                            <label>Kategori Bahan <span class="text-danger">*</span></label>
                            <select name="kategori_bahan_id" class="form-control" required>
                                <option value="">-- Pilih Kategori --</option>
                                <?php foreach ($kategori_bahan as $kat): ?>
                                    <option value="<?= $kat->id; ?>"><?= html_escape($kat->nama); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-8 form-group">
                            <label>Nama Bahan <span class="text-danger">*</span></label>
                            <input type="text" name="nama" class="form-control" placeholder="Cth: Asam Klorida (HCl 37%)" required>
                        </div>
                        <div class="col-md-4 form-group">
                            <label>Satuan Satuan <span class="text-danger">*</span></label>
                            <select name="satuan_id" class="form-control" required>
                                <option value="">-- Pilih Satuan --</option>
                                <?php foreach ($satuan as $st): ?>
                                    <option value="<?= $st->id; ?>"><?= html_escape($st->nama); ?> (<?= html_escape($st->simbol); ?>)</option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4 form-group">
                            <label>Rumus Kimia</label>
                            <input type="text" name="rumus_kimia" class="form-control" placeholder="Cth: HCl">
                        </div>
                        <div class="col-md-4 form-group">
                            <label>Nomor CAS</label>
                            <input type="text" name="nomor_cas" class="form-control" placeholder="Cth: 7647-01-0">
                        </div>
                        <div class="col-md-4 form-group">
                            <label>Batas Stok Minimum</label>
                            <input type="number" step="0.001" name="stok_minimum" class="form-control" value="0.000">
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Jenis Bahaya / Simbol GHS</label>
                        <input type="text" name="jenis_bahaya" class="form-control" placeholder="Cth: Korosif, Beracun, Mudah Terbakar">
                    </div>
                    <div class="form-group">
                        <label>Petunjuk Penyimpanan</label>
                        <textarea name="petunjuk_penyimpanan" class="form-control" rows="2" placeholder="Cth: Simpan di lemari asam dengan ventilasi baik."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                    <button type="submit" class="btn btn-danger">Simpan Bahan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $this->load->view('layout/footer'); ?>