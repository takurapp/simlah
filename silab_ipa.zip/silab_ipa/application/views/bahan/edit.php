<?php
$this->load->view('layout/header');
$this->load->view('layout/navbar');
$this->load->view('layout/sidebar');
?>

<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 font-weight-bold"><?= html_escape($judul); ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?= site_url('dashboard'); ?>">Home</a></li>
                        <li class="breadcrumb-item"><a href="<?= site_url('bahan'); ?>">Bahan</a></li>
                        <li class="breadcrumb-item active">Edit</li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-8">
                    <div class="card card-warning">
                        <div class="card-header">
                            <h3 class="card-title text-white font-weight-bold">Form Edit Data Bahan</h3>
                        </div>

                        <?= validation_errors('<div class="alert alert-danger m-3"><i class="fas fa-exclamation-triangle mr-1"></i> ', '</div>'); ?>

                        <form action="<?= site_url('bahan/update/' . $bahan->id); ?>" method="post">
                            <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">

                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label for="kode">Kode Bahan <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="kode" name="kode" value="<?= set_value('kode', $bahan->kode); ?>" required>
                                    </div>
                                    <div class="col-md-6 form-group">
                                        <label for="kategori_bahan_id">Kategori Bahan <span class="text-danger">*</span></label>
                                        <select class="form-control" id="kategori_bahan_id" name="kategori_bahan_id" required>
                                            <option value="">-- Pilih Kategori --</option>
                                            <?php foreach ($kategori_bahan as $kat): ?>
                                                <option value="<?= $kat->id; ?>" <?= set_select('kategori_bahan_id', $kat->id, ($kat->id == $bahan->kategori_bahan_id)); ?>>
                                                    <?= html_escape($kat->nama); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-8 form-group">
                                        <label for="nama">Nama Bahan <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="nama" name="nama" value="<?= set_value('nama', $bahan->nama); ?>" required>
                                    </div>
                                    <div class="col-md-4 form-group">
                                        <label for="satuan_id">Satuan Ukuran <span class="text-danger">*</span></label>
                                        <select class="form-control" id="satuan_id" name="satuan_id" required>
                                            <option value="">-- Pilih Satuan --</option>
                                            <?php foreach ($satuan as $st): ?>
                                                <option value="<?= $st->id; ?>" <?= set_select('satuan_id', $st->id, ($st->id == $bahan->satuan_id)); ?>>
                                                    <?= html_escape($st->nama); ?> (<?= html_escape($st->simbol); ?>)
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-4 form-group">
                                        <label for="rumus_kimia">Rumus Kimia</label>
                                        <input type="text" class="form-control" id="rumus_kimia" name="rumus_kimia" value="<?= set_value('rumus_kimia', $bahan->rumus_kimia); ?>">
                                    </div>
                                    <div class="col-md-4 form-group">
                                        <label for="nomor_cas">Nomor CAS</label>
                                        <input type="text" class="form-control" id="nomor_cas" name="nomor_cas" value="<?= set_value('nomor_cas', $bahan->nomor_cas); ?>">
                                    </div>
                                    <div class="col-md-4 form-group">
                                        <label for="stok_minimum">Batas Stok Minimum</label>
                                        <input type="number" step="0.001" class="form-control" id="stok_minimum" name="stok_minimum" value="<?= set_value('stok_minimum', $bahan->stok_minimum); ?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="jenis_bahaya">Jenis Bahaya / Karakteristik</label>
                                    <input type="text" class="form-control" id="jenis_bahaya" name="jenis_bahaya" value="<?= set_value('jenis_bahaya', $bahan->jenis_bahaya); ?>">
                                </div>

                                <div class="form-group">
                                    <label for="petunjuk_penyimpanan">Petunjuk Penyimpanan</label>
                                    <textarea class="form-control" id="petunjuk_penyimpanan" name="petunjuk_penyimpanan" rows="2"><?= set_value('petunjuk_penyimpanan', $bahan->petunjuk_penyimpanan); ?></textarea>
                                </div>
                            </div>

                            <div class="card-footer">
                                <button type="submit" class="btn btn-warning text-white"><i class="fas fa-save mr-1"></i> Perbarui</button>
                                <a href="<?= site_url('bahan'); ?>" class="btn btn-secondary ml-2"><i class="fas fa-arrow-left mr-1"></i> Batal</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<?php $this->load->view('layout/footer'); ?>