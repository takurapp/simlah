<?php
$this->load->view('layout/header');
$this->load->view('layout/navbar');
$this->load->view('layout/sidebar');
?>

<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 font-weight-bold">Batch & Stok Bahan</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?= site_url('dashboard'); ?>">Home</a></li>
                        <li class="breadcrumb-item"><a href="<?= site_url('bahan'); ?>">Bahan</a></li>
                        <li class="breadcrumb-item active">Batch</li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="container-fluid">

            <?php if ($this->session->flashdata('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="icon fas fa-check mr-1"></i> <?= html_escape($this->session->flashdata('success')); ?>
                    <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span></button>
                </div>
            <?php endif; ?>

            <?php if ($this->session->flashdata('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="icon fas fa-ban mr-1"></i> <?= html_escape($this->session->flashdata('error')); ?>
                    <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span></button>
                </div>
            <?php endif; ?>

            <!-- Ringkasan Master Bahan -->
            <div class="card card-outline card-danger">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-3"><strong>Kode:</strong> <?= html_escape($bahan->kode); ?></div>
                        <div class="col-md-3"><strong>Nama:</strong> <?= html_escape($bahan->nama); ?></div>
                        <div class="col-md-3"><strong>Kategori:</strong> <?= html_escape($bahan->kategori_nama); ?></div>
                        <div class="col-md-3"><strong>Satuan:</strong> <?= html_escape($bahan->satuan_nama); ?> (<?= html_escape($bahan->satuan_simbol); ?>)</div>
                    </div>
                </div>
            </div>

            <!-- Tabel Daftar Batch -->
            <div class="card card-outline card-primary">
                <div class="card-header">
                    <h3 class="card-title font-weight-bold">Daftar Batch & Masa Berlaku</h3>
                    <div class="card-tools">
                        <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#modal-tambah-batch">
                            <i class="fas fa-plus mr-1"></i> Penerimaan Batch Baru
                        </button>
                        <a href="<?= site_url('bahan'); ?>" class="btn btn-secondary btn-sm ml-1">
                            <i class="fas fa-arrow-left mr-1"></i> Kembali
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th style="width: 40px;">No</th>
                                <th>No. Batch</th>
                                <th>Penempatan Lab</th>
                                <th>Lokasi Lemari/Rak</th>
                                <th>Tgl Kedaluwarsa</th>
                                <th>Stok Awal</th>
                                <th>Tersedia</th>
                                <th style="width: 120px;" class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($batches)): ?>
                                <tr>
                                    <td colspan="8" class="text-center text-muted">Belum ada batch bahan yang dicatat.</td>
                                </tr>
                            <?php else: ?>
                                <?php $no = 1;
                                foreach ($batches as $b): ?>
                                    <tr>
                                        <td><?= $no++; ?></td>
                                        <td><strong><?= html_escape($b->nomor_batch); ?></strong></td>
                                        <td><?= html_escape($b->lab_nama ?: 'Gudang Pusat'); ?></td>
                                        <td><?= html_escape($b->lokasi_penyimpanan ?: '-'); ?></td>
                                        <td>
                                            <?php if ($b->tanggal_kedaluwarsa): ?>
                                                <?php if (strtotime($b->tanggal_kedaluwarsa) < time()): ?>
                                                    <span class="badge badge-danger"><?= html_escape($b->tanggal_kedaluwarsa); ?> (Expired)</span>
                                                <?php else: ?>
                                                    <?= html_escape($b->tanggal_kedaluwarsa); ?>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <span class="text-muted">-</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?= number_format((float)$b->jumlah_awal, 2); ?> <?= html_escape($bahan->satuan_simbol); ?></td>
                                        <td>
                                            <strong><?= number_format((float)$b->jumlah_tersedia, 2); ?></strong> <?= html_escape($bahan->satuan_simbol); ?>
                                        </td>
                                        <td class="text-center">
                                            <?php if ((float)$b->jumlah_tersedia > 0): ?>
                                                <button type="button" class="btn btn-warning btn-sm btn-pakai"
                                                    data-id="<?= $b->id; ?>"
                                                    data-batch="<?= html_escape($b->nomor_batch); ?>"
                                                    data-sisa="<?= (float)$b->jumlah_tersedia; ?>">
                                                    <i class="fas fa-minus-circle mr-1"></i> Pakai
                                                </button>
                                            <?php else: ?>
                                                <span class="badge badge-secondary">Habis</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </section>
</div>

<!-- Modal Tambah Batch -->
<div class="modal fade" id="modal-tambah-batch" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="<?= site_url('bahan/simpan_batch/' . $bahan->id); ?>" method="post">
                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
                <div class="modal-header">
                    <h5 class="modal-title font-weight-bold">Input Batch Bahan Masuk</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label>Nomor Batch Pabrik <span class="text-danger">*</span></label>
                        <input type="text" name="nomor_batch" class="form-control" placeholder="Cth: BATCH-2026-X01" required>
                    </div>
                    <div class="form-group">
                        <label>Jumlah Masuk (<?= html_escape($bahan->satuan_simbol); ?>) <span class="text-danger">*</span></label>
                        <input type="number" step="0.001" name="jumlah_awal" class="form-control" placeholder="0.000" required>
                    </div>
                    <div class="form-group">
                        <label>Penempatan Ruang Lab</label>
                        <select name="laboratorium_id" class="form-control">
                            <option value="">-- Gudang Bahan / Utama --</option>
                            <?php foreach ($labs as $lab): ?>
                                <option value="<?= $lab->id; ?>"><?= html_escape($lab->nama); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Lokasi Rak / Lemari Penyimpanan</label>
                        <input type="text" name="lokasi_penyimpanan" class="form-control" placeholder="Cth: Lemari Asam No. 3">
                    </div>
                    <div class="row">
                        <div class="col-md-6 form-group">
                            <label>Tanggal Diterima</label>
                            <input type="date" name="tanggal_diterima" class="form-control" value="<?= date('Y-m-d'); ?>">
                        </div>
                        <div class="col-md-6 form-group">
                            <label>Tanggal Kedaluwarsa</label>
                            <input type="date" name="tanggal_kedaluwarsa" class="form-control">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                    <button type="submit" class="btn btn-primary">Simpan Batch Masuk</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Pemakaian Bahan -->
<div class="modal fade" id="modal-pakai-bahan" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="<?= site_url('bahan/pakai_stok/' . $bahan->id); ?>" method="post">
                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
                <input type="hidden" name="batch_id" id="modal_batch_id">
                <div class="modal-header">
                    <h5 class="modal-title font-weight-bold">Catat Penggunaan Bahan</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label>Nomor Batch</label>
                        <input type="text" id="modal_batch_nomor" class="form-control" readonly>
                    </div>
                    <div class="form-group">
                        <label>Jumlah Digunakan (<?= html_escape($bahan->satuan_simbol); ?>) <span class="text-danger">*</span></label>
                        <input type="number" step="0.001" name="jumlah" id="modal_jumlah" class="form-control" min="0.001" required>
                        <small class="text-muted">Maksimal penggunaan: <span id="modal_sisa_text"></span> <?= html_escape($bahan->satuan_simbol); ?></small>
                    </div>
                    <div class="form-group">
                        <label>Alasan / Untuk Praktikum Apa <span class="text-danger">*</span></label>
                        <textarea name="alasan" class="form-control" rows="2" placeholder="Cth: Praktikum Titrasi Asam Basa Kelas XI IPA 1" required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-warning">Konfirmasi Pakai</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        const buttons = document.querySelectorAll('.btn-pakai');
        buttons.forEach(function(button) {
            button.addEventListener('click', function() {
                const id = this.getAttribute('data-id');
                const batch = this.getAttribute('data-batch');
                const sisa = this.getAttribute('data-sisa');

                document.getElementById('modal_batch_id').value = id;
                document.getElementById('modal_batch_nomor').value = batch;
                document.getElementById('modal_jumlah').max = sisa;
                document.getElementById('modal_sisa_text').innerText = sisa;

                $('#modal-pakai-bahan').modal('show');
            });
        });
    });
</script>

<?php $this->load->view('layout/footer'); ?>