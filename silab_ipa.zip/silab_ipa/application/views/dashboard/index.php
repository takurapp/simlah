<?php
$this->load->view('layout/header');
$this->load->view('layout/navbar');
$this->load->view('layout/sidebar');
?>

<div class="content-wrapper">
    <!-- Header Konten -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 font-weight-bold">Dashboard SIM LAB IPA</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?= site_url('dashboard'); ?>">Home</a></li>
                        <li class="breadcrumb-item active">Dashboard</li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <!-- Konten Utama -->
    <section class="content">
        <div class="container-fluid">

            <!-- Banner Sambutan -->
            <div class="alert alert-primary alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h5><i class="icon fas fa-info-circle"></i> Selamat Datang, <?= html_escape($this->session->userdata('nama')); ?>!</h5>
                Anda masuk sebagai <strong><?= strtoupper(html_escape($this->session->userdata('role'))); ?></strong> pada Sistem Informasi Manajemen Laboratorium IPA Sekolah.
            </div>

            <!-- Kartu Statistik (Small Boxes) -->
            <div class="row">
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-info">
                        <div class="inner">
                            <h3><?= $total_lab; ?></h3>
                            <p>Ruang Laboratorium</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-door-open"></i>
                        </div>
                        <a href="<?= site_url('laboratorium'); ?>" class="small-box-footer">
                            Lihat Detail <i class="fas fa-arrow-circle-right"></i>
                        </a>
                    </div>
                </div>

                <div class="col-lg-3 col-6">
                    <div class="small-box bg-success">
                        <div class="inner">
                            <h3><?= $total_alat; ?></h3>
                            <p>Katalog Alat IPA</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-microscope"></i>
                        </div>
                        <a href="<?= site_url('alat'); ?>" class="small-box-footer">
                            Lihat Detail <i class="fas fa-arrow-circle-right"></i>
                        </a>
                    </div>
                </div>

                <div class="col-lg-3 col-6">
                    <div class="small-box bg-warning">
                        <div class="inner">
                            <h3><?= $total_unit; ?></h3>
                            <p>Total Unit Inventaris</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-boxes"></i>
                        </div>
                        <a href="<?= site_url('alat'); ?>" class="small-box-footer">
                            Lihat Detail <i class="fas fa-arrow-circle-right"></i>
                        </a>
                    </div>
                </div>

                <div class="col-lg-3 col-6">
                    <div class="small-box bg-danger">
                        <div class="inner">
                            <h3><?= $total_bahan; ?></h3>
                            <p>Bahan Kimia / Reagen</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-vials"></i>
                        </div>
                        <a href="<?= site_url('bahan'); ?>" class="small-box-footer">
                            Lihat Detail <i class="fas fa-arrow-circle-right"></i>
                        </a>
                    </div>
                </div>
            </div>

            <!-- Tabel & Ringkasan Alokasi -->
            <div class="row">
                <div class="col-lg-8">
                    <div class="card card-outline card-primary">
                        <div class="card-header">
                            <h3 class="card-title font-weight-bold">
                                <i class="fas fa-list-alt mr-1"></i> Status Ruang Laboratorium
                            </h3>
                        </div>
                        <div class="card-body p-0 table-responsive">
                            <table class="table table-striped table-valign-middle">
                                <thead>
                                    <tr>
                                        <th>Kode</th>
                                        <th>Nama Lab</th>
                                        <th>Lokasi</th>
                                        <th>Kapasitas</th>
                                        <th>Total Alat</th>
                                        <th>Total Batch Bahan</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($list_lab)): ?>
                                        <tr>
                                            <td colspan="6" class="text-center py-3 text-muted">Belum ada ruang laboratorium terdaftar.</td>
                                        </tr>
                                    <?php else: ?>
                                        <?php foreach ($list_lab as $lab): ?>
                                            <tr>
                                                <td><span class="badge badge-secondary"><?= html_escape($lab->kode); ?></span></td>
                                                <td><strong><?= html_escape($lab->nama); ?></strong></td>
                                                <td><?= html_escape($lab->lokasi ?: '-'); ?></td>
                                                <td><?= $lab->kapasitas ? html_escape($lab->kapasitas) . ' Siswa' : '-'; ?></td>
                                                <td><span class="badge badge-info"><?= $lab->total_alat; ?> Unit</span></td>
                                                <td><span class="badge badge-warning"><?= $lab->total_batch; ?> Batch</span></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Pintasan Cepat -->
                <div class="col-lg-4">
                    <div class="card card-outline card-secondary">
                        <div class="card-header">
                            <h3 class="card-title font-weight-bold">
                                <i class="fas fa-bolt mr-1"></i> Menu Cepat
                            </h3>
                        </div>
                        <div class="card-body">
                            <p class="text-muted text-sm">Pilih aksi cepat pengelolaan operasional laboratorium:</p>
                            <a href="<?= site_url('laboratorium/tambah'); ?>" class="btn btn-outline-primary btn-block mb-2 text-left">
                                <i class="fas fa-plus-circle mr-2"></i> Tambah Ruang Lab Baru
                            </a>
                            <a href="<?= site_url('alat'); ?>" class="btn btn-outline-success btn-block mb-2 text-left">
                                <i class="fas fa-tools mr-2"></i> Kelola Master & Unit Alat
                            </a>
                            <a href="<?= site_url('bahan'); ?>" class="btn btn-outline-danger btn-block mb-2 text-left">
                                <i class="fas fa-flask mr-2"></i> Input Stok Bahan Kimia
                            </a>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section>
</div>

<?php $this->load->view('layout/footer'); ?>