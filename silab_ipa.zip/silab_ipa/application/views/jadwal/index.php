<?php
$this->load->view('layout/header');
$this->load->view('layout/navbar');
$this->load->view('layout/sidebar');
?>

<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 font-weight-bold"><?= html_escape($judul); ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?= site_url('dashboard'); ?>">Home</a></li>
                        <li class="breadcrumb-item active">Jadwal Lab</li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="container-fluid">

            <?php if ($this->session->flashdata('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="icon fas fa-check mr-1"></i> <?= html_escape($this->session->flashdata('success')); ?>
                    <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span></button>
                </div>
            <?php endif; ?>

            <?php if ($this->session->flashdata('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="icon fas fa-ban mr-1"></i> <?= html_escape($this->session->flashdata('error')); ?>
                    <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span></button>
                </div>
            <?php endif; ?>

            <!-- Filter Card -->
            <div class="card card-outline card-primary">
                <div class="card-header">
                    <h3 class="card-title font-weight-bold"><i class="fas fa-calendar-alt mr-1"></i> Filter Kalender Pemakaian</h3>
                    <div class="card-tools">
                        <a href="<?= site_url('jadwal/tambah'); ?>" class="btn btn-primary btn-sm">
                            <i class="fas fa-plus mr-1"></i> Booking Jadwal
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <form action="<?= site_url('jadwal'); ?>" method="get">
                        <div class="row">
                            <div class="col-md-5 form-group">
                                <label>Ruang Laboratorium</label>
                                <select name="laboratorium_id" class="form-control">
                                    <option value="">-- Semua Ruang Laboratorium --</option>
                                    <?php foreach ($laboratorium as $lab): ?>
                                        <option value="<?= $lab->id; ?>" <?= ($lab_id == $lab->id) ? 'selected' : ''; ?>>
                                            <?= html_escape($lab->nama); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-5 form-group">
                                <label>Tanggal Pemakaian</label>
                                <input type="date" name="tanggal" class="form-control" value="<?= html_escape($tanggal); ?>">
                            </div>
                            <div class="col-md-2 form-group d-flex align-items-end">
                                <button type="submit" class="btn btn-primary btn-block"><i class="fas fa-search mr-1"></i> Filter</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Tabel Jadwal -->
            <div class="card card-outline card-secondary">
                <div class="card-header">
                    <h3 class="card-title font-weight-bold">Daftar Agenda Praktikum</h3>
                </div>
                <div class="card-body p-0 table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th style="width: 40px;">No</th>
                                <th>Tanggal & Waktu</th>
                                <th>Ruang Lab</th>
                                <th>Kelas</th>
                                <th>Guru Pengampu</th>
                                <th>Materi Praktikum</th>
                                <th>Status</th>
                                <th style="width: 140px;" class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($jadwal)): ?>
                                <tr>
                                    <td colspan="8" class="text-center text-muted py-4">Belum ada agenda praktikum yang dijadwalkan.</td>
                                </tr>
                            <?php else: ?>
                                <?php $no = 1;
                                foreach ($jadwal as $j): ?>
                                    <tr>
                                        <td><?= $no++; ?></td>
                                        <td>
                                            <strong><?= date('d/m/Y', strtotime($j->tanggal)); ?></strong><br>
                                            <small class="text-muted"><?= substr($j->jam_mulai, 0, 5); ?> - <?= substr($j->jam_selesai, 0, 5); ?> WIB</small>
                                        </td>
                                        <td><?= html_escape($j->nama_lab ?: '-'); ?></td>
                                        <td><span class="badge badge-secondary"><?= html_escape($j->kelas); ?></span></td>
                                        <td><?= html_escape($j->nama_guru); ?></td>
                                        <td>
                                            <strong><?= html_escape($j->materi_praktikum); ?></strong><br>
                                            <small class="text-muted"><?= html_escape($j->mata_pelajaran); ?></small>
                                        </td>
                                        <td>
                                            <?php if ($j->status === 'terjadwal'): ?>
                                                <span class="badge badge-primary">Terjadwal</span>
                                            <?php elseif ($j->status === 'berlangsung'): ?>
                                                <span class="badge badge-warning">Berlangsung</span>
                                            <?php elseif ($j->status === 'selesai'): ?>
                                                <span class="badge badge-success">Selesai</span>
                                            <?php else: ?>
                                                <span class="badge badge-danger">Dibatalkan</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center">
                                            <div class="btn-group">
                                                <button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown">
                                                    Status
                                                </button>
                                                <div class="dropdown-menu dropdown-menu-right">
                                                    <form action="<?= site_url('jadwal/ubah_status/' . $j->id . '/berlangsung'); ?>" method="post">
                                                        <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
                                                        <button type="submit" class="dropdown-item text-warning">Set Berlangsung</button>
                                                    </form>
                                                    <form action="<?= site_url('jadwal/ubah_status/' . $j->id . '/selesai'); ?>" method="post">
                                                        <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
                                                        <button type="submit" class="dropdown-item text-success">Set Selesai</button>
                                                    </form>
                                                    <form action="<?= site_url('jadwal/ubah_status/' . $j->id . '/dibatalkan'); ?>" method="post">
                                                        <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
                                                        <button type="submit" class="dropdown-item text-danger">Batalkan</button>
                                                    </form>
                                                </div>
                                            </div>

                                            <form action="<?= site_url('jadwal/hapus/' . $j->id); ?>" method="post" class="d-inline ml-1" onsubmit="return confirm('Hapus jadwal ini?');">
                                                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
                                                <button type="submit" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </section>
</div>

<?php $this->load->view('layout/footer'); ?>