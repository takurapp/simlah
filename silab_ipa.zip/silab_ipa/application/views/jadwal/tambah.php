<?php
$this->load->view('layout/header');
$this->load->view('layout/navbar');
$this->load->view('layout/sidebar');
?>

<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 font-weight-bold"><?= html_escape($judul); ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?= site_url('dashboard'); ?>">Home</a></li>
                        <li class="breadcrumb-item"><a href="<?= site_url('jadwal'); ?>">Jadwal</a></li>
                        <li class="breadcrumb-item active">Booking</li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-8">
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title font-weight-bold">Formulir Pendaftaran Jadwal Praktikum</h3>
                        </div>

                        <?php if ($this->session->flashdata('error')): ?>
                            <div class="alert alert-danger m-3">
                                <i class="fas fa-ban mr-1"></i> <?= html_escape($this->session->flashdata('error')); ?>
                            </div>
                        <?php endif; ?>

                        <?= validation_errors('<div class="alert alert-danger m-3"><i class="fas fa-exclamation-triangle mr-1"></i> ', '</div>'); ?>

                        <form action="<?= site_url('jadwal/simpan'); ?>" method="post">
                            <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">

                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label>Ruang Laboratorium <span class="text-danger">*</span></label>
                                        <select name="laboratorium_id" class="form-control" required>
                                            <option value="">-- Pilih Ruang Lab --</option>
                                            <?php foreach ($laboratorium as $lab): ?>
                                                <option value="<?= $lab->id; ?>" <?= set_select('laboratorium_id', $lab->id); ?>>
                                                    <?= html_escape($lab->nama); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="col-md-6 form-group">
                                        <label>Guru Pengampu <span class="text-danger">*</span></label>
                                        <select name="user_id" class="form-control" required>
                                            <option value="">-- Pilih Guru --</option>
                                            <?php foreach ($guru as $g): ?>
                                                <option value="<?= $g->id; ?>" <?= set_select('user_id', $g->id, ($g->id == $this->session->userdata('user_id'))); ?>>
                                                    <?= html_escape($g->nama_lengkap); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label>Kelas <span class="text-danger">*</span></label>
                                        <input type="text" name="kelas" class="form-control" placeholder="Cth: VII-A / VIII-IPA-1" value="<?= set_value('kelas'); ?>" required>
                                    </div>
                                    <div class="col-md-6 form-group">
                                        <label>Mata Pelajaran <span class="text-danger">*</span></label>
                                        <input type="text" name="mata_pelajaran" class="form-control" value="<?= set_value('mata_pelajaran', 'IPA Terpadu'); ?>" required>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label>Materi / Topik Praktikum <span class="text-danger">*</span></label>
                                    <input type="text" name="materi_praktikum" class="form-control" placeholder="Cth: Uji Asam Basa Larutan Menggunakan Kertas Lakmus" value="<?= set_value('materi_praktikum'); ?>" required>
                                </div>

                                <div class="row">
                                    <div class="col-md-4 form-group">
                                        <label>Tanggal Praktikum <span class="text-danger">*</span></label>
                                        <input type="date" name="tanggal" class="form-control" value="<?= set_value('tanggal', date('Y-m-d')); ?>" required>
                                    </div>
                                    <div class="col-md-4 form-group">
                                        <label>Jam Mulai <span class="text-danger">*</span></label>
                                        <input type="time" name="jam_mulai" class="form-control" value="<?= set_value('jam_mulai', '08:00'); ?>" required>
                                    </div>
                                    <div class="col-md-4 form-group">
                                        <label>Jam Selesai <span class="text-danger">*</span></label>
                                        <input type="time" name="jam_selesai" class="form-control" value="<?= set_value('jam_selesai', '09:30'); ?>" required>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label>Keterangan Tambahan</label>
                                    <textarea name="keterangan" class="form-control" rows="2" placeholder="Catatan kesiapan alat atau pendamping praktikum"><?= set_value('keterangan'); ?></textarea>
                                </div>
                            </div>

                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary"><i class="fas fa-save mr-1"></i> Simpan Jadwal</button>
                                <a href="<?= site_url('jadwal'); ?>" class="btn btn-secondary ml-2"><i class="fas fa-arrow-left mr-1"></i> Batal</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<?php $this->load->view('layout/footer'); ?>