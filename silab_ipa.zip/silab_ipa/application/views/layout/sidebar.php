<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="<?= site_url('dashboard'); ?>" class="brand-link">
        <i class="fas fa-flask ml-3 mr-2"></i>
        <span class="brand-text font-weight-light">SIM LAB IPA</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">

                <li class="nav-item">
                    <a href="<?= site_url('dashboard'); ?>" class="nav-link <?= ($this->uri->segment(1) == 'dashboard') ? 'active' : ''; ?>">
                        <i class="nav-icon fas fa-tachometer-alt"></i>
                        <p>Dashboard</p>
                    </a>
                </li>

                <?php if ($this->session->userdata('role') === 'admin'): ?>
                    <li class="nav-header">MASTER DATA</li>
                    <li class="nav-item">
                        <a href="<?= site_url('users'); ?>" class="nav-link <?= ($this->uri->segment(1) == 'users') ? 'active' : ''; ?>">
                            <i class="nav-icon fas fa-users-cog"></i>
                            <p>Manajemen Pengguna</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?= site_url('laboratorium'); ?>" class="nav-link <?= ($this->uri->segment(1) == 'laboratorium') ? 'active' : ''; ?>">
                            <i class="nav-icon fas fa-door-open"></i>
                            <p>Data Ruang Lab</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?= site_url('kategori'); ?>" class="nav-link <?= ($this->uri->segment(1) == 'kategori') ? 'active' : ''; ?>">
                            <i class="nav-icon fas fa-tags"></i>
                            <p>Kategori Alat & Bahan</p>
                        </a>
                    </li>
                <?php endif; ?>

                <li class="nav-header">INVENTARIS</li>
                <li class="nav-item">
                    <a href="<?= site_url('alat'); ?>" class="nav-link <?= ($this->uri->segment(1) == 'alat') ? 'active' : ''; ?>">
                        <i class="nav-icon fas fa-microscope"></i>
                        <p>Alat Laboratorium</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?= site_url('bahan'); ?>" class="nav-link <?= ($this->uri->segment(1) == 'bahan') ? 'active' : ''; ?>">
                        <i class="nav-icon fas fa-vials"></i>
                        <p>Bahan Kimia / Habis Pakai</p>
                    </a>
                </li>

                <li class="nav-header">TRANSAKSI</li>
                <li class="nav-item">
                    <a href="<?= site_url('jadwal'); ?>" class="nav-link <?= ($this->uri->segment(1) == 'jadwal') ? 'active' : ''; ?>">
                        <i class="nav-icon fas fa-calendar-alt"></i>
                        <p>Jadwal Ruang Lab</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?= site_url('peminjaman'); ?>" class="nav-link <?= ($this->uri->segment(1) == 'peminjaman') ? 'active' : ''; ?>">
                        <i class="nav-icon fas fa-clipboard-list"></i>
                        <p>Peminjaman Alat</p>
                    </a>
                </li>
                <li class="nav-header">LAPORAN</li>
                <li class="nav-item">
                    <a href="<?= site_url('laporan/peminjaman'); ?>" class="nav-link <?= ($this->uri->segment(1) == 'laporan' && $this->uri->segment(2) == 'peminjaman') ? 'active' : ''; ?>">
                        <i class="nav-icon fas fa-file-alt"></i>
                        <p>Laporan Peminjaman</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?= site_url('laporan/bahan'); ?>" class="nav-link <?= ($this->uri->segment(1) == 'laporan' && $this->uri->segment(2) == 'bahan') ? 'active' : ''; ?>">
                        <i class="nav-icon fas fa-chart-line"></i>
                        <p>Mutasi Bahan Kimia</p>
                    </a>
                </li>

            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside>