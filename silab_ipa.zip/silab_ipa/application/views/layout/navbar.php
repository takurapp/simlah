<!-- Navbar -->
<nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
        </li>
    </ul>

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
        <li class="nav-item dropdown user-menu">
            <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">
                <i class="fas fa-user-circle mr-1"></i>
                <span class="d-none d-md-inline"><?= html_escape($this->session->userdata('nama')); ?></span>
            </a>
            <ul class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
                <li class="user-header bg-primary">
                    <i class="fas fa-user fa-3x text-white my-2"></i>
                    <p>
                        <?= html_escape($this->session->userdata('nama')); ?>
                        <small>Role: <?= strtoupper($this->session->userdata('role')); ?></small>
                    </p>
                </li>
                <li class="user-footer">
                    <form action="<?= site_url('auth/logout'); ?>" method="post">
                        <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
                        <button type="submit" class="btn btn-danger btn-flat float-right"><i class="fas fa-sign-out-alt mr-1"></i> Logout</button>
                    </form>
                </li>
            </ul>
        </li>
    </ul>
</nav>
<!-- /.navbar -->