<?php
$this->load->view('layout/header');
$this->load->view('layout/navbar');
$this->load->view('layout/sidebar');
?>

<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 font-weight-bold"><?= html_escape($judul); ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?= site_url('dashboard'); ?>">Home</a></li>
                        <li class="breadcrumb-item active">Kategori & Satuan</li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="container-fluid">

            <?php if ($this->session->flashdata('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="icon fas fa-check mr-1"></i> <?= html_escape($this->session->flashdata('success')); ?>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Tutup"><span aria-hidden="true">&times;</span></button>
                </div>
            <?php endif; ?>

            <?php if ($this->session->flashdata('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="icon fas fa-ban mr-1"></i> <?= html_escape($this->session->flashdata('error')); ?>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Tutup"><span aria-hidden="true">&times;</span></button>
                </div>
            <?php endif; ?>

            <div class="card card-primary card-outline card-outline-tabs">
                <div class="card-header p-0 border-bottom-0">
                    <ul class="nav nav-tabs" id="custom-tabs-four-tab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active font-weight-bold" id="tab-alat-tab" data-toggle="pill" href="#tab-alat" role="tab"><i class="fas fa-microscope mr-1"></i> Kategori Alat</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link font-weight-bold" id="tab-bahan-tab" data-toggle="pill" href="#tab-bahan" role="tab"><i class="fas fa-vials mr-1"></i> Kategori Bahan</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link font-weight-bold" id="tab-satuan-tab" data-toggle="pill" href="#tab-satuan" role="tab"><i class="fas fa-balance-scale mr-1"></i> Satuan Unit</a>
                        </li>
                    </ul>
                </div>

                <div class="card-body">
                    <div class="tab-content" id="custom-tabs-four-tabContent">

                        <!-- TAB KATEGORI ALAT -->
                        <div class="tab-pane fade show active" id="tab-alat" role="tabpanel">
                            <div class="d-flex justify-content-between mb-3">
                                <h5 class="font-weight-bold text-muted my-auto">Senarai Kategori Alat</h5>
                                <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#modal-alat">
                                    <i class="fas fa-plus mr-1"></i> Tambah Kategori Alat
                                </button>
                            </div>
                            <table class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th style="width: 50px;">No</th>
                                        <th>Kod</th>
                                        <th>Nama Kategori</th>
                                        <th>Keterangan</th>
                                        <th style="width: 100px;" class="text-center">Tindakan</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($kategori_alat)): ?>
                                        <tr>
                                            <td colspan="5" class="text-center text-muted">Tiada data kategori alat.</td>
                                        </tr>
                                    <?php else: ?>
                                        <?php $no = 1;
                                        foreach ($kategori_alat as $ka): ?>
                                            <tr>
                                                <td><?= $no++; ?></td>
                                                <td><span class="badge badge-info"><?= html_escape($ka->kode); ?></span></td>
                                                <td><strong><?= html_escape($ka->nama); ?></strong></td>
                                                <td><?= html_escape($ka->keterangan ?: '-'); ?></td>
                                                <td class="text-center">
                                                    <form action="<?= site_url('kategori/hapus_alat/' . $ka->id); ?>" method="post" class="d-inline" onsubmit="return confirm('Padam kategori ini?');">
                                                        <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
                                                        <button type="submit" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>

                        <!-- TAB KATEGORI BAHAN -->
                        <div class="tab-pane fade" id="tab-bahan" role="tabpanel">
                            <div class="d-flex justify-content-between mb-3">
                                <h5 class="font-weight-bold text-muted my-auto">Senarai Kategori Bahan</h5>
                                <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#modal-bahan">
                                    <i class="fas fa-plus mr-1"></i> Tambah Kategori Bahan
                                </button>
                            </div>
                            <table class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th style="width: 50px;">No</th>
                                        <th>Kod</th>
                                        <th>Nama Kategori</th>
                                        <th>Keterangan</th>
                                        <th style="width: 100px;" class="text-center">Tindakan</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($kategori_bahan)): ?>
                                        <tr>
                                            <td colspan="5" class="text-center text-muted">Tiada data kategori bahan.</td>
                                        </tr>
                                    <?php else: ?>
                                        <?php $no = 1;
                                        foreach ($kategori_bahan as $kb): ?>
                                            <tr>
                                                <td><?= $no++; ?></td>
                                                <td><span class="badge badge-warning"><?= html_escape($kb->kode); ?></span></td>
                                                <td><strong><?= html_escape($kb->nama); ?></strong></td>
                                                <td><?= html_escape($kb->keterangan ?: '-'); ?></td>
                                                <td class="text-center">
                                                    <form action="<?= site_url('kategori/hapus_bahan/' . $kb->id); ?>" method="post" class="d-inline" onsubmit="return confirm('Padam kategori ini?');">
                                                        <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
                                                        <button type="submit" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>

                        <!-- TAB SATUAN -->
                        <div class="tab-pane fade" id="tab-satuan" role="tabpanel">
                            <div class="d-flex justify-content-between mb-3">
                                <h5 class="font-weight-bold text-muted my-auto">Senarai Satuan Unit</h5>
                                <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#modal-satuan">
                                    <i class="fas fa-plus mr-1"></i> Tambah Satuan
                                </button>
                            </div>
                            <table class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th style="width: 50px;">No</th>
                                        <th>Nama Satuan</th>
                                        <th>Simbol Simpanan</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($satuan)): ?>
                                        <tr>
                                            <td colspan="3" class="text-center text-muted">Tiada data unit ukuran.</td>
                                        </tr>
                                    <?php else: ?>
                                        <?php $no = 1;
                                        foreach ($satuan as $st): ?>
                                            <tr>
                                                <td><?= $no++; ?></td>
                                                <td><strong><?= html_escape($st->nama); ?></strong></td>
                                                <td><span class="badge badge-success"><?= html_escape($st->simbol); ?></span></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>

        </div>
    </section>
</div>

<!-- Modal Tambah Kategori Alat -->
<div class="modal fade" id="modal-alat" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="<?= site_url('kategori/simpan_alat'); ?>" method="post">
                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
                <div class="modal-header">
                    <h5 class="modal-title font-weight-bold">Tambah Kategori Alat</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label>Kod Kategori <span class="text-danger">*</span></label>
                        <input type="text" name="kode" class="form-control" placeholder="Cth: OPTIK, ELEKTRONIK" required>
                    </div>
                    <div class="form-group">
                        <label>Nama Kategori <span class="text-danger">*</span></label>
                        <input type="text" name="nama" class="form-control" placeholder="Cth: Peralatan Optik & Lensa" required>
                    </div>
                    <div class="form-group">
                        <label>Keterangan</label>
                        <textarea name="keterangan" class="form-control" rows="2"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Tambah Kategori Bahan -->
<div class="modal fade" id="modal-bahan" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="<?= site_url('kategori/simpan_bahan'); ?>" method="post">
                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
                <div class="modal-header">
                    <h5 class="modal-title font-weight-bold">Tambah Kategori Bahan</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label>Kod Kategori <span class="text-danger">*</span></label>
                        <input type="text" name="kode" class="form-control" placeholder="Cth: ASID, BASA, INDIKATOR" required>
                    </div>
                    <div class="form-group">
                        <label>Nama Kategori <span class="text-danger">*</span></label>
                        <input type="text" name="nama" class="form-control" placeholder="Cth: Bahan Kimia Asid Pekat" required>
                    </div>
                    <div class="form-group">
                        <label>Keterangan</label>
                        <textarea name="keterangan" class="form-control" rows="2"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Tambah Satuan -->
<div class="modal fade" id="modal-satuan" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="<?= site_url('kategori/simpan_satuan'); ?>" method="post">
                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
                <div class="modal-header">
                    <h5 class="modal-title font-weight-bold">Tambah Satuan Ukuran</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label>Nama Satuan <span class="text-danger">*</span></label>
                        <input type="text" name="nama" class="form-control" placeholder="Cth: Gram, Mililiter, Botol" required>
                    </div>
                    <div class="form-group">
                        <label>Simbol Satuan <span class="text-danger">*</span></label>
                        <input type="text" name="simbol" class="form-control" placeholder="Cth: g, ml, btl" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $this->load->view('layout/footer'); ?>