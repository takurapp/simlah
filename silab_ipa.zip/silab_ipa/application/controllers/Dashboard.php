<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Dashboard extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Dashboard_model');
    }

    public function index()
    {
        $data['judul']             = 'Dashboard SIM LAB IPA';
        $data['total_lab']         = $this->Dashboard_model->count_laboratorium();
        $data['total_alat']        = $this->Dashboard_model->count_alat();
        $data['total_unit']        = $this->Dashboard_model->count_unit_alat();
        $data['total_bahan']       = $this->Dashboard_model->count_bahan();
        $data['list_lab']          = $this->Dashboard_model->get_laboratorium_ringkasan();
        $data['kondisi_alat']      = $this->Dashboard_model->get_unit_alat_by_kondisi();

        $this->load->view('dashboard/index', $data);
    }
}
