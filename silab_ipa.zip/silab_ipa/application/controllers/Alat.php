<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Alat extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model(array('Alat_model', 'Kategori_model', 'Laboratorium_model'));
        $this->load->library('form_validation');
        $this->load->helper(array('form', 'url'));
    }

    public function index()
    {
        $data['judul']         = 'Katalog Alat Laboratorium';
        $data['alat']          = $this->Alat_model->get_all();
        $data['kategori_alat'] = $this->Kategori_model->get_kategori_alat();
        $this->load->view('alat/index', $data);
    }

    public function simpan()
    {
        if ($this->input->method(TRUE) !== 'POST') {
            show_404();
            return;
        }

        $this->form_validation->set_rules('kode', 'Kode Alat', 'required|trim|is_unique[alat.kode]');
        $this->form_validation->set_rules('nama', 'Nama Alat', 'required|trim');
        $this->form_validation->set_rules('kategori_alat_id', 'Kategori Alat', 'required|numeric');

        if ($this->form_validation->run() === FALSE) {
            $this->session->set_flashdata('error', validation_errors(' ', ' '));
            redirect('alat');
            return;
        }

        $payload = array(
            'kategori_alat_id' => (int) $this->input->post('kategori_alat_id', TRUE),
            'kode'             => strtoupper($this->input->post('kode', TRUE)),
            'nama'             => $this->input->post('nama', TRUE),
            'spesifikasi'      => $this->input->post('spesifikasi', TRUE) ?: NULL,
            'merek'            => $this->input->post('merek', TRUE) ?: NULL,
            'satuan'           => $this->input->post('satuan', TRUE) ?: 'unit',
            'keterangan'       => $this->input->post('keterangan', TRUE) ?: NULL,
            'aktif'            => 1
        );

        $this->Alat_model->insert($payload);
        $this->session->set_flashdata('success', 'Master data alat berhasil ditambahkan.');
        redirect('alat');
    }

    public function detail($id)
    {
        $alat = $this->Alat_model->get_by_id($id);
        if (!$alat) {
            show_404();
            return;
        }

        $data['judul'] = 'Detail & Unit Alat: ' . $alat->nama;
        $data['alat']  = $alat;
        $data['units'] = $this->Alat_model->get_units_by_alat_id($id);
        $data['labs']  = $this->Laboratorium_model->get_all(true);

        $this->load->view('alat/detail', $data);
    }

    public function simpan_unit($alat_id)
    {
        if ($this->input->method(TRUE) !== 'POST') {
            show_404();
            return;
        }

        $this->form_validation->set_rules('nomor_inventaris', 'Nomor Inventaris', 'required|trim|is_unique[unit_alat.nomor_inventaris]');
        $this->form_validation->set_rules('kondisi', 'Kondisi', 'required|in_list[baik,rusak_ringan,rusak_berat]');

        if ($this->form_validation->run() === FALSE) {
            $this->session->set_flashdata('error', validation_errors(' ', ' '));
            redirect('alat/detail/' . $alat_id);
            return;
        }

        $payload = array(
            'alat_id'           => (int) $alat_id,
            'laboratorium_id'   => $this->input->post('laboratorium_id') ? (int) $this->input->post('laboratorium_id') : NULL,
            'nomor_inventaris'  => strtoupper($this->input->post('nomor_inventaris', TRUE)),
            'nomor_seri'        => $this->input->post('nomor_seri', TRUE) ?: NULL,
            'tanggal_perolehan' => $this->input->post('tanggal_perolehan', TRUE) ?: NULL,
            'harga_perolehan'   => $this->input->post('harga_perolehan') ? (float) $this->input->post('harga_perolehan') : NULL,
            'kondisi'           => $this->input->post('kondisi', TRUE),
            'status'            => 'tersedia',
            'keterangan'        => $this->input->post('keterangan', TRUE) ?: NULL
        );

        $this->Alat_model->insert_unit($payload);
        $this->session->set_flashdata('success', 'Unit inventaris alat berhasil didaftarkan.');
        redirect('alat/detail/' . $alat_id);
    }

    public function hapus_unit($alat_id, $unit_id)
    {
        if ($this->input->method(TRUE) !== 'POST') {
            show_404();
            return;
        }

        $this->Alat_model->delete_unit($unit_id);
        $this->session->set_flashdata('success', 'Unit inventaris berhasil dihapus.');
        redirect('alat/detail/' . $alat_id);
    }

    public function hapus($id)
    {
        if ($this->input->method(TRUE) !== 'POST') {
            show_404();
            return;
        }

        if (!$this->Alat_model->delete($id)) {
            $this->session->set_flashdata('error', 'Katalog alat tidak dapat dihapus karena sudah memiliki unit fisik terdaftar.');
        } else {
            $this->session->set_flashdata('success', 'Katalog alat berhasil dihapus.');
        }

        redirect('alat');
    }

    public function edit($id)
    {
        $alat = $this->Alat_model->get_by_id($id);
        if (!$alat) {
            show_404();
            return;
        }

        $data['judul']         = 'Edit Master Alat';
        $data['alat']          = $alat;
        $data['kategori_alat'] = $this->Kategori_model->get_kategori_alat();
        $this->load->view('alat/edit', $data);
    }

    public function update($id)
    {
        if ($this->input->method(TRUE) !== 'POST') {
            show_404();
            return;
        }

        $alat = $this->Alat_model->get_by_id($id);
        if (!$alat) {
            show_404();
            return;
        }

        // Cek keunikan kode jika kode diubah
        $is_unique = ($this->input->post('kode') != $alat->kode) ? '|is_unique[alat.kode]' : '';
        $this->form_validation->set_rules('kode', 'Kode Alat', 'required|trim' . $is_unique);
        $this->form_validation->set_rules('nama', 'Nama Alat', 'required|trim');
        $this->form_validation->set_rules('kategori_alat_id', 'Kategori Alat', 'required|numeric');

        if ($this->form_validation->run() === FALSE) {
            $this->edit($id);
            return;
        }

        $payload = array(
            'kategori_alat_id' => (int) $this->input->post('kategori_alat_id', TRUE),
            'kode'             => strtoupper($this->input->post('kode', TRUE)),
            'nama'             => $this->input->post('nama', TRUE),
            'spesifikasi'      => $this->input->post('spesifikasi', TRUE) ?: NULL,
            'merek'            => $this->input->post('merek', TRUE) ?: NULL,
            'satuan'           => $this->input->post('satuan', TRUE) ?: 'unit',
            'keterangan'       => $this->input->post('keterangan', TRUE) ?: NULL
        );

        $this->Alat_model->update($id, $payload);
        $this->session->set_flashdata('success', 'Master data alat berhasil diperbarui.');
        redirect('alat');
    }

    public function cetak_label($alat_id, $unit_id = null)
    {
        $alat = $this->Alat_model->get_by_id($alat_id);
        if (!$alat) {
            show_404();
            return;
        }

        $data['alat'] = $alat;

        if ($unit_id !== null) {
            // Cetak 1 label spesifik
            $unit = $this->db->select('ua.*, l.nama as lab_nama')
                ->from('unit_alat ua')
                ->join('laboratorium l', 'l.id = ua.laboratorium_id', 'left')
                ->where('ua.id', (int) $unit_id)
                ->get()->row();

            $data['units'] = $unit ? array($unit) : array();
        } else {
            // Cetak seluruh label unit dari alat ini
            $data['units'] = $this->Alat_model->get_units_by_alat_id($alat_id);
        }

        $this->load->view('alat/cetak_label', $data);
    }
}
