<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Laporan extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model(array('Laporan_model', 'Laboratorium_model', 'Bahan_model'));
        $this->load->helper(array('url', 'form'));
    }

    public function index()
    {
        redirect('laporan/peminjaman');
    }

    // 1. Laporan Peminjaman Alat
    public function peminjaman()
    {
        $data['judul']        = 'Laporan Peminjaman Alat';
        $data['laboratorium'] = $this->Laboratorium_model->get_all(true);

        $tgl_mulai   = $this->input->get('tgl_mulai', TRUE) ?: date('Y-m-01');
        $tgl_selesai = $this->input->get('tgl_selesai', TRUE) ?: date('Y-m-d');
        $lab_id      = $this->input->get('laboratorium_id', TRUE);
        $status      = $this->input->get('status', TRUE);

        $data['tgl_mulai']   = $tgl_mulai;
        $data['tgl_selesai'] = $tgl_selesai;
        $data['lab_id']      = $lab_id;
        $data['status']      = $status;

        $data['laporan'] = $this->Laporan_model->get_laporan_peminjaman($tgl_mulai, $tgl_selesai, $lab_id, $status);

        $this->load->view('laporan/peminjaman', $data);
    }

    public function cetak_peminjaman()
    {
        $tgl_mulai   = $this->input->get('tgl_mulai', TRUE);
        $tgl_selesai = $this->input->get('tgl_selesai', TRUE);
        $lab_id      = $this->input->get('laboratorium_id', TRUE);
        $status      = $this->input->get('status', TRUE);

        $data['tgl_mulai']   = $tgl_mulai;
        $data['tgl_selesai'] = $tgl_selesai;
        $data['laporan']     = $this->Laporan_model->get_laporan_peminjaman($tgl_mulai, $tgl_selesai, $lab_id, $status);

        $this->load->view('laporan/cetak_peminjaman', $data);
    }

    // 2. Laporan Mutasi & Pemakaian Bahan Kimia
    public function bahan()
    {
        $data['judul'] = 'Laporan Pemakaian & Mutasi Bahan';
        $data['bahan'] = $this->Bahan_model->get_all();

        $tgl_mulai   = $this->input->get('tgl_mulai', TRUE) ?: date('Y-m-01');
        $tgl_selesai = $this->input->get('tgl_selesai', TRUE) ?: date('Y-m-d');
        $bahan_id    = $this->input->get('bahan_id', TRUE);
        $jenis       = $this->input->get('jenis', TRUE);

        $data['tgl_mulai']   = $tgl_mulai;
        $data['tgl_selesai'] = $tgl_selesai;
        $data['bahan_id']    = $bahan_id;
        $data['jenis']       = $jenis;

        $data['laporan'] = $this->Laporan_model->get_laporan_mutasi_bahan($tgl_mulai, $tgl_selesai, $bahan_id, $jenis);

        $this->load->view('laporan/bahan', $data);
    }

    public function cetak_bahan()
    {
        $tgl_mulai   = $this->input->get('tgl_mulai', TRUE);
        $tgl_selesai = $this->input->get('tgl_selesai', TRUE);
        $bahan_id    = $this->input->get('bahan_id', TRUE);
        $jenis       = $this->input->get('jenis', TRUE);

        $data['tgl_mulai']   = $tgl_mulai;
        $data['tgl_selesai'] = $tgl_selesai;
        $data['laporan']     = $this->Laporan_model->get_laporan_mutasi_bahan($tgl_mulai, $tgl_selesai, $bahan_id, $jenis);

        $this->load->view('laporan/cetak_bahan', $data);
    }
}
