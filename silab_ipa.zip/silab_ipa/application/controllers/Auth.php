
<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Auth extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        $this->load->model('Auth_model');
        $this->load->library(array('session', 'form_validation')); // Tambahkan form_validation$this->load->helper(array('url', 'form'));
    }

    public function index()
    {
        if ($this->session->userdata('logged_in')) {
            redirect('dashboard');
        }

        $this->load->view('auth/login');
    }

    public function login()
    {
        if ($this->input->method(TRUE) !== 'POST') {
            show_404();
            return;
        }

        $this->form_validation->set_rules(
            'username',
            'Username',
            'required|trim'
        );

        $this->form_validation->set_rules(
            'password',
            'Password',
            'required'
        );

        if ($this->form_validation->run() === FALSE) {
            $this->load->view('auth/login');
            return;
        }

        $username = $this->input->post('username', TRUE);
        $password = $this->input->post('password');

        $user = $this->Auth_model->login($username, $password);

        if (!$user) {
            $this->session->set_flashdata(
                'error',
                'Username atau password salah, atau akun tidak aktif.'
            );

            redirect('auth');
            return;
        }

        // Mencegah session fixation setelah login berhasil.
        $this->session->sess_regenerate(TRUE);

        $this->session->set_userdata(array(
            'user_id'    => $user->id,
            'nama'       => $user->nama_lengkap,
            'username'   => $user->username,
            'role'       => $user->role,
            'logged_in'  => TRUE
        ));

        redirect('dashboard');
    }

    public function logout()
    {
        if ($this->input->method(TRUE) !== 'POST') {
            show_404();
            return;
        }

        $this->session->sess_destroy();

        redirect('auth');
    }
}
