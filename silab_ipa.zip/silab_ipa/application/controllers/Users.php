
<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Users extends Admin_Controller
{
    public function __construct()
    {
        parent::__construct();

        $this->load->model('Users_model');
        $this->load->library('form_validation');
        $this->load->helper(array('url', 'form'));
    }

    public function index()
    {
        $data['judul'] = 'Manajemen Pengguna';
        $data['users'] = $this->Users_model->get_all();

        $this->load->view('users/index', $data);
    }

    public function create()
    {
        $this->form_validation->set_rules(
            'nama_lengkap',
            'Nama lengkap',
            'required|trim'
        );
        $this->form_validation->set_rules(
            'username',
            'Username',
            'required|trim|alpha_numeric'
        );
        $this->form_validation->set_rules(
            'password',
            'Password',
            'required|min_length[12]'
        );
        $this->form_validation->set_rules(
            'role',
            'Peran',
            'required|in_list[admin,guru,laboran]'
        );

        if ($this->form_validation->run() === FALSE) {
            $this->load->view('users/form', array(
                'judul' => 'Tambah Pengguna',
                'user' => NULL,
                'aksi' => 'create'
            ));
            return;
        }

        $username = $this->input->post('username', TRUE);

        if ($this->Users_model->username_exists($username)) {
            $this->session->set_flashdata(
                'error',
                'Username sudah digunakan.'
            );
            redirect('users/create');
            return;
        }

        $data = array(
            'nama_lengkap' => $this->input->post('nama_lengkap', TRUE),
            'nomor_induk' => $this->input->post('nomor_induk', TRUE) ?: NULL,
            'username' => $username,
            'password' => password_hash(
                $this->input->post('password'),
                PASSWORD_DEFAULT
            ),
            'role' => $this->input->post('role', TRUE),
            'nomor_telepon' => $this->input->post('nomor_telepon', TRUE),
            'aktif' => 1,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        );

        if (!$this->Users_model->create($data)) {
            show_error('Gagal menyimpan pengguna.');
            return;
        }

        $this->session->set_flashdata(
            'success',
            'Pengguna berhasil ditambahkan.'
        );
        redirect('users');
    }

    public function edit($id = NULL)
    {
        $id = (int) $id;
        $user = $this->Users_model->get_by_id($id);

        if (!$user) {
            show_404();
            return;
        }

        $this->form_validation->set_rules(
            'nama_lengkap',
            'Nama lengkap',
            'required|trim'
        );
        $this->form_validation->set_rules(
            'username',
            'Username',
            'required|trim|alpha_numeric'
        );
        $this->form_validation->set_rules(
            'role',
            'Peran',
            'required|in_list[admin,guru,laboran]'
        );
        $this->form_validation->set_rules(
            'password',
            'Password baru',
            'min_length[12]'
        );

        if ($this->form_validation->run() === FALSE) {
            $this->load->view('users/form', array(
                'judul' => 'Edit Pengguna',
                'user' => $user,
                'aksi' => 'edit/' . $id
            ));
            return;
        }

        $username = $this->input->post('username', TRUE);

        if ($this->Users_model->username_exists($username, $id)) {
            $this->session->set_flashdata(
                'error',
                'Username sudah digunakan.'
            );
            redirect('users/edit/' . $id);
            return;
        }

        // Jangan mengizinkan Admin menonaktifkan atau
        // menurunkan peran akunnya sendiri.
        $role = $this->input->post('role', TRUE);

        if (
            $id === (int) $this->session->userdata('user_id')
            && $role !== 'admin'
        ) {
            $this->session->set_flashdata(
                'error',
                'Peran akun Admin yang sedang digunakan tidak dapat diturunkan.'
            );
            redirect('users/edit/' . $id);
            return;
        }

        $data = array(
            'nama_lengkap' => $this->input->post('nama_lengkap', TRUE),
            'nomor_induk' => $this->input->post('nomor_induk', TRUE) ?: NULL,
            'username' => $username,
            'role' => $role,
            'nomor_telepon' => $this->input->post('nomor_telepon', TRUE),
            'updated_at' => date('Y-m-d H:i:s')
        );

        $password = $this->input->post('password');

        if ($password !== '') {
            $data['password'] = password_hash(
                $password,
                PASSWORD_DEFAULT
            );
        }

        if (!$this->Users_model->update_user($id, $data)) {
            show_error('Gagal memperbarui pengguna.');
            return;
        }

        $this->session->set_flashdata(
            'success',
            'Data pengguna berhasil diperbarui.'
        );
        redirect('users');
    }

    public function toggle_status($id = NULL)
    {
        if ($this->input->method(TRUE) !== 'POST') {
            show_404();
            return;
        }

        $id = (int) $id;
        $user = $this->Users_model->get_by_id($id);

        if (!$user) {
            show_404();
            return;
        }

        if ($id === (int) $this->session->userdata('user_id')) {
            $this->session->set_flashdata(
                'error',
                'Anda tidak dapat menonaktifkan akun sendiri.'
            );
            redirect('users');
            return;
        }

        $aktif_baru = $user->aktif ? 0 : 1;

        if (!$this->Users_model->set_active($id, $aktif_baru)) {
            show_error('Gagal mengubah status pengguna.');
            return;
        }

        $this->session->set_flashdata(
            'success',
            $aktif_baru ? 'Pengguna diaktifkan.' : 'Pengguna dinonaktifkan.'
        );

        redirect('users');
    }
}
