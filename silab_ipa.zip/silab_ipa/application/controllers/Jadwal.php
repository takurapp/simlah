<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Jadwal extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model(array('Jadwal_model', 'Laboratorium_model', 'Users_model'));
        $this->load->library('form_validation');
        $this->load->helper(array('form', 'url'));
    }

    public function index()
    {
        $data['judul']        = 'Jadwal Penggunaan Ruang Laboratorium';
        $data['laboratorium'] = $this->Laboratorium_model->get_all(true);

        $lab_id  = $this->input->get('laboratorium_id', TRUE);
        $tanggal = $this->input->get('tanggal', TRUE);

        $data['lab_id']  = $lab_id;
        $data['tanggal'] = $tanggal;
        $data['jadwal']  = $this->Jadwal_model->get_all($lab_id, $tanggal);

        $this->load->view('jadwal/index', $data);
    }

    public function tambah()
    {
        $data['judul']        = 'Booking Jadwal Praktikum';
        $data['laboratorium'] = $this->Laboratorium_model->get_all(true);
        $data['guru']         = $this->Users_model->get_all();

        $this->load->view('jadwal/tambah', $data);
    }

    public function simpan()
    {
        if ($this->input->method(TRUE) !== 'POST') {
            show_404();
            return;
        }

        $this->form_validation->set_rules('laboratorium_id', 'Ruang Laboratorium', 'required|numeric');
        $this->form_validation->set_rules('user_id', 'Guru Pengampu', 'required|numeric');
        $this->form_validation->set_rules('kelas', 'Kelas', 'required|trim');
        $this->form_validation->set_rules('mata_pelajaran', 'Mata Pelajaran', 'required|trim');
        $this->form_validation->set_rules('materi_praktikum', 'Materi Praktikum', 'required|trim');
        $this->form_validation->set_rules('tanggal', 'Tanggal', 'required');
        $this->form_validation->set_rules('jam_mulai', 'Jam Mulai', 'required');
        $this->form_validation->set_rules('jam_selesai', 'Jam Selesai', 'required');

        if ($this->form_validation->run() === FALSE) {
            $this->tambah();
            return;
        }

        $lab_id      = (int) $this->input->post('laboratorium_id', TRUE);
        $tanggal     = $this->input->post('tanggal', TRUE);
        $jam_mulai   = $this->input->post('jam_mulai', TRUE);
        $jam_selesai = $this->input->post('jam_selesai', TRUE);

        if ($jam_mulai >= $jam_selesai) {
            $this->session->set_flashdata('error', 'Jam selesai harus lebih akhir dari jam mulai.');
            redirect('jadwal/tambah');
            return;
        }

        // Cek apakah ruangan sudah terpakai di jam tersebut
        if ($this->Jadwal_model->check_bentrok($lab_id, $tanggal, $jam_mulai, $jam_selesai)) {
            $this->session->set_flashdata('error', 'Ruang laboratorium sudah terpakai pada rentang tanggal dan jam tersebut. Silakan pilih waktu lain.');
            redirect('jadwal/tambah');
            return;
        }

        $payload = array(
            'laboratorium_id'  => $lab_id,
            'user_id'          => (int) $this->input->post('user_id', TRUE),
            'kelas'            => strtoupper($this->input->post('kelas', TRUE)),
            'mata_pelajaran'   => $this->input->post('mata_pelajaran', TRUE),
            'materi_praktikum' => $this->input->post('materi_praktikum', TRUE),
            'tanggal'          => $tanggal,
            'jam_mulai'        => $jam_mulai,
            'jam_selesai'      => $jam_selesai,
            'status'           => 'terjadwal',
            'keterangan'       => $this->input->post('keterangan', TRUE) ?: NULL
        );

        $this->Jadwal_model->insert($payload);
        $this->session->set_flashdata('success', 'Jadwal praktikum laboratorium berhasil didaftarkan.');
        redirect('jadwal');
    }

    public function ubah_status($id, $status)
    {
        if ($this->input->method(TRUE) !== 'POST') {
            show_404();
            return;
        }

        if (!in_array($status, array('terjadwal', 'berlangsung', 'selesai', 'dibatalkan'), true)) {
            show_404();
            return;
        }

        $this->Jadwal_model->update($id, array('status' => $status));
        $this->session->set_flashdata('success', 'Status jadwal berhasil diperbarui.');
        redirect('jadwal');
    }

    public function hapus($id)
    {
        if ($this->input->method(TRUE) !== 'POST') {
            show_404();
            return;
        }

        $this->Jadwal_model->delete($id);
        $this->session->set_flashdata('success', 'Jadwal praktikum berhasil dihapus.');
        redirect('jadwal');
    }
}
