<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Peminjaman extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        // Muat model Users_model bersama model lainnya
        $this->load->model(array('Peminjaman_model', 'Laboratorium_model', 'Users_model'));
        $this->load->library('form_validation');
        $this->load->helper(array('form', 'url'));
    }

    public function index()
    {
        $data['judul'] = 'Daftar Peminjaman Alat IPA';
        $user_id       = $this->session->userdata('user_id');
        $role          = $this->session->userdata('role');

        $data['peminjaman'] = $this->Peminjaman_model->get_all($user_id, $role);
        $this->load->view('peminjaman/index', $data);
    }

    public function tambah()
    {
        $data['judul']         = 'Formulir Pinjam Alat Laboratorium';
        $data['laboratorium']  = $this->Laboratorium_model->get_all(true);
        $data['unit_tersedia'] = $this->Peminjaman_model->get_unit_tersedia();
        // Ambil semua daftar user untuk dropdown peminjam
        $data['users']         = $this->Users_model->get_all();

        $this->load->view('peminjaman/tambah', $data);
    }

    public function simpan()
    {
        if ($this->input->method(TRUE) !== 'POST') {
            show_404();
            return;
        }

        // Tambahkan validasi untuk user_id peminjam
        $this->form_validation->set_rules('user_id', 'Nama Peminjam', 'required|numeric');
        $this->form_validation->set_rules('laboratorium_id', 'Ruang Laboratorium', 'required|numeric');
        $this->form_validation->set_rules('tanggal_pinjam', 'Tanggal & Waktu Pinjam', 'required');
        $this->form_validation->set_rules('rencana_kembali', 'Rencana Tanggal Kembali', 'required');
        $this->form_validation->set_rules('keperluan', 'Keperluan Praktikum', 'required|trim');

        $unit_alat_ids = $this->input->post('unit_alat_id');
        if (empty($unit_alat_ids) || !is_array($unit_alat_ids)) {
            $this->session->set_flashdata('error', 'Pilih minimal satu unit alat yang akan dipinjam.');
            redirect('peminjaman/tambah');
            return;
        }

        if ($this->form_validation->run() === FALSE) {
            $this->tambah();
            return;
        }

        $kode_transaksi = 'PINJAM-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -4));

        $payload = array(
            'laboratorium_id'  => (int) $this->input->post('laboratorium_id', TRUE),
            // Ambil ID peminjam yang dipilih dari dropdown form
            'user_id'          => (int) $this->input->post('user_id', TRUE),
            'nomor_peminjaman' => $kode_transaksi,
            'tanggal_pinjam'   => $this->input->post('tanggal_pinjam', TRUE),
            'rencana_kembali'  => $this->input->post('rencana_kembali', TRUE),
            'keperluan'        => $this->input->post('keperluan', TRUE),
            'status'           => 'dipinjam',
            'created_at'       => date('Y-m-d H:i:s'),
            'updated_at'       => date('Y-m-d H:i:s')
        );

        $simpan = $this->Peminjaman_model->insert_pengajuan($payload, $unit_alat_ids);

        if ($simpan) {
            $this->session->set_flashdata('success', 'Peminjaman alat berhasil dicatat dengan kode: ' . $kode_transaksi);
        } else {
            $this->session->set_flashdata('error', 'Terjadi kesalahan saat memproses data peminjaman.');
        }

        redirect('peminjaman');
    }

    public function detail($id)
    {
        $peminjaman = $this->Peminjaman_model->get_by_id($id);
        if (!$peminjaman) {
            show_404();
            return;
        }

        $data['judul']  = 'Detail Peminjaman: ' . $peminjaman->nomor_peminjaman;
        $data['pinjam'] = $peminjaman;
        $data['items']  = $this->Peminjaman_model->get_detail_items($id);

        $this->load->view('peminjaman/detail', $data);
    }

    public function proses_kembali($id)
    {
        if (!in_array($this->session->userdata('role'), array('admin', 'laboran'), true)) {
            show_error('Hanya Laboran atau Admin yang berhak memverifikasi pengembalian alat.', 403, 'Akses Ditolak');
            return;
        }

        if ($this->input->method(TRUE) !== 'POST') {
            show_404();
            return;
        }

        $kondisi_kembali = $this->input->post('kondisi_kembali');
        $catatan         = $this->input->post('catatan');
        $petugas_id      = $this->session->userdata('user_id');

        $kembali = $this->Peminjaman_model->proses_kembali($id, $petugas_id, $kondisi_kembali, $catatan);

        if ($kembali) {
            $this->session->set_flashdata('success', 'Pengembalian alat telah diverifikasi. Stok unit kini kembali tersedia.');
        } else {
            $this->session->set_flashdata('error', 'Gagal memproses pengembalian alat.');
        }

        redirect('peminjaman/detail/' . $id);
    }

    public function cetak($id)
    {
        $peminjaman = $this->Peminjaman_model->get_by_id($id);
        if (!$peminjaman) {
            show_404();
            return;
        }

        $data['pinjam'] = $peminjaman;
        $data['items']  = $this->Peminjaman_model->get_detail_items($id);

        $this->load->view('peminjaman/cetak', $data);
    }
}
