<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Kategori extends Admin_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Kategori_model');
        $this->load->library('form_validation');
        $this->load->helper(array('form', 'url'));
    }

    public function index()
    {
        $data['judul']          = 'Master Kategori & Satuan';
        $data['kategori_alat']  = $this->Kategori_model->get_kategori_alat();
        $data['kategori_bahan'] = $this->Kategori_model->get_kategori_bahan();
        $data['satuan']         = $this->Kategori_model->get_satuan();

        $this->load->view('kategori/index', $data);
    }

    public function simpan_alat()
    {
        if ($this->input->method(TRUE) !== 'POST') {
            show_404();
            return;
        }

        $this->form_validation->set_rules('kode', 'Kod Kategori', 'required|trim|is_unique[kategori_alat.kode]');
        $this->form_validation->set_rules('nama', 'Nama Kategori', 'required|trim|is_unique[kategori_alat.nama]');

        if ($this->form_validation->run() === FALSE) {
            $this->session->set_flashdata('error', validation_errors(' ', ' '));
            redirect('kategori');
            return;
        }

        $payload = array(
            'kode'       => strtoupper($this->input->post('kode', TRUE)),
            'nama'       => $this->input->post('nama', TRUE),
            'keterangan' => $this->input->post('keterangan', TRUE) ?: NULL
        );

        $this->Kategori_model->insert_kategori_alat($payload);
        $this->session->set_flashdata('success', 'Kategori alat berjaya ditambah.');
        redirect('kategori');
    }

    public function hapus_alat($id)
    {
        if ($this->input->method(TRUE) !== 'POST') {
            show_404();
            return;
        }

        if (!$this->Kategori_model->delete_kategori_alat($id)) {
            $this->session->set_flashdata('error', 'Kategori alat tidak boleh dipadam kerana masih digunakan oleh inventori alat.');
        } else {
            $this->session->set_flashdata('success', 'Kategori alat berjaya dipadam.');
        }

        redirect('kategori');
    }

    public function simpan_bahan()
    {
        if ($this->input->method(TRUE) !== 'POST') {
            show_404();
            return;
        }

        $this->form_validation->set_rules('kode', 'Kod Kategori', 'required|trim|is_unique[kategori_bahan.kode]');
        $this->form_validation->set_rules('nama', 'Nama Kategori', 'required|trim|is_unique[kategori_bahan.nama]');

        if ($this->form_validation->run() === FALSE) {
            $this->session->set_flashdata('error', validation_errors(' ', ' '));
            redirect('kategori');
            return;
        }

        $payload = array(
            'kode'       => strtoupper($this->input->post('kode', TRUE)),
            'nama'       => $this->input->post('nama', TRUE),
            'keterangan' => $this->input->post('keterangan', TRUE) ?: NULL
        );

        $this->Kategori_model->insert_kategori_bahan($payload);
        $this->session->set_flashdata('success', 'Kategori bahan berjaya ditambah.');
        redirect('kategori');
    }

    public function hapus_bahan($id)
    {
        if ($this->input->method(TRUE) !== 'POST') {
            show_404();
            return;
        }

        if (!$this->Kategori_model->delete_kategori_bahan($id)) {
            $this->session->set_flashdata('error', 'Kategori bahan tidak boleh dipadam kerana masih digunakan oleh inventori bahan.');
        } else {
            $this->session->set_flashdata('success', 'Kategori bahan berjaya dipadam.');
        }

        redirect('kategori');
    }

    public function simpan_satuan()
    {
        if ($this->input->method(TRUE) !== 'POST') {
            show_404();
            return;
        }

        $this->form_validation->set_rules('nama', 'Nama Satuan', 'required|trim|is_unique[satuan.nama]');
        $this->form_validation->set_rules('simbol', 'Simbol Satuan', 'required|trim|is_unique[satuan.simbol]');

        if ($this->form_validation->run() === FALSE) {
            $this->session->set_flashdata('error', validation_errors(' ', ' '));
            redirect('kategori');
            return;
        }

        $payload = array(
            'nama'   => $this->input->post('nama', TRUE),
            'simbol' => $this->input->post('simbol', TRUE)
        );

        $this->Kategori_model->insert_satuan($payload);
        $this->session->set_flashdata('success', 'Satuan unit berjaya ditambah.');
        redirect('kategori');
    }
}
