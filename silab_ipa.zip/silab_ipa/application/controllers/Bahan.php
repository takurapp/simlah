<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Bahan extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model(array('Bahan_model', 'Kategori_model', 'Laboratorium_model'));
        $this->load->library('form_validation');
        $this->load->helper(array('form', 'url'));
    }

    public function index()
    {
        $data['judul']          = 'Katalog Bahan Kimia & Habis Pakai';
        $data['bahan']          = $this->Bahan_model->get_all();
        $data['kategori_bahan'] = $this->Kategori_model->get_kategori_bahan();
        $data['satuan']         = $this->Kategori_model->get_satuan();

        $this->load->view('bahan/index', $data);
    }

    public function simpan()
    {
        if ($this->input->method(TRUE) !== 'POST') {
            show_404();
            return;
        }

        $this->form_validation->set_rules('kode', 'Kode Bahan', 'required|trim|is_unique[bahan.kode]');
        $this->form_validation->set_rules('nama', 'Nama Bahan', 'required|trim');
        $this->form_validation->set_rules('kategori_bahan_id', 'Kategori Bahan', 'required|numeric');
        $this->form_validation->set_rules('satuan_id', 'Satuan', 'required|numeric');

        if ($this->form_validation->run() === FALSE) {
            $this->session->set_flashdata('error', validation_errors(' ', ' '));
            redirect('bahan');
            return;
        }

        $payload = array(
            'kategori_bahan_id'    => (int) $this->input->post('kategori_bahan_id', TRUE),
            'satuan_id'            => (int) $this->input->post('satuan_id', TRUE),
            'kode'                 => strtoupper($this->input->post('kode', TRUE)),
            'nama'                 => $this->input->post('nama', TRUE),
            'rumus_kimia'          => $this->input->post('rumus_kimia', TRUE) ?: NULL,
            'nomor_cas'            => $this->input->post('nomor_cas', TRUE) ?: NULL,
            'jenis_bahaya'         => $this->input->post('jenis_bahaya', TRUE) ?: NULL,
            'petunjuk_penyimpanan' => $this->input->post('petunjuk_penyimpanan', TRUE) ?: NULL,
            'stok_minimum'         => (float) $this->input->post('stok_minimum', TRUE),
            'keterangan'           => $this->input->post('keterangan', TRUE) ?: NULL,
            'aktif'                => 1
        );

        $this->Bahan_model->insert($payload);
        $this->session->set_flashdata('success', 'Master bahan kimia berhasil ditambahkan.');
        redirect('bahan');
    }

    public function edit($id)
    {
        $bahan = $this->Bahan_model->get_by_id($id);
        if (!$bahan) {
            show_404();
            return;
        }

        $data['judul']          = 'Edit Master Bahan Kimia';
        $data['bahan']          = $bahan;
        $data['kategori_bahan'] = $this->Kategori_model->get_kategori_bahan();
        $data['satuan']         = $this->Kategori_model->get_satuan();

        $this->load->view('bahan/edit', $data);
    }

    public function update($id)
    {
        if ($this->input->method(TRUE) !== 'POST') {
            show_404();
            return;
        }

        $bahan = $this->Bahan_model->get_by_id($id);
        if (!$bahan) {
            show_404();
            return;
        }

        $is_unique = ($this->input->post('kode') != $bahan->kode) ? '|is_unique[bahan.kode]' : '';
        $this->form_validation->set_rules('kode', 'Kode Bahan', 'required|trim' . $is_unique);
        $this->form_validation->set_rules('nama', 'Nama Bahan', 'required|trim');
        $this->form_validation->set_rules('kategori_bahan_id', 'Kategori Bahan', 'required|numeric');
        $this->form_validation->set_rules('satuan_id', 'Satuan', 'required|numeric');

        if ($this->form_validation->run() === FALSE) {
            $this->edit($id);
            return;
        }

        $payload = array(
            'kategori_bahan_id'    => (int) $this->input->post('kategori_bahan_id', TRUE),
            'satuan_id'            => (int) $this->input->post('satuan_id', TRUE),
            'kode'                 => strtoupper($this->input->post('kode', TRUE)),
            'nama'                 => $this->input->post('nama', TRUE),
            'rumus_kimia'          => $this->input->post('rumus_kimia', TRUE) ?: NULL,
            'nomor_cas'            => $this->input->post('nomor_cas', TRUE) ?: NULL,
            'jenis_bahaya'         => $this->input->post('jenis_bahaya', TRUE) ?: NULL,
            'petunjuk_penyimpanan' => $this->input->post('petunjuk_penyimpanan', TRUE) ?: NULL,
            'stok_minimum'         => (float) $this->input->post('stok_minimum', TRUE),
            'keterangan'           => $this->input->post('keterangan', TRUE) ?: NULL
        );

        $this->Bahan_model->update($id, $payload);
        $this->session->set_flashdata('success', 'Master bahan kimia berhasil diperbarui.');
        redirect('bahan');
    }

    public function detail($id)
    {
        $bahan = $this->Bahan_model->get_by_id($id);
        if (!$bahan) {
            show_404();
            return;
        }

        $data['judul']   = 'Batch & Stok: ' . $bahan->nama;
        $data['bahan']   = $bahan;
        $data['batches'] = $this->Bahan_model->get_batches_by_bahan_id($id);
        $data['labs']    = $this->Laboratorium_model->get_all(true);

        $this->load->view('bahan/detail', $data);
    }

    public function simpan_batch($bahan_id)
    {
        if ($this->input->method(TRUE) !== 'POST') {
            show_404();
            return;
        }

        $this->form_validation->set_rules('nomor_batch', 'Nomor Batch', 'required|trim');
        $this->form_validation->set_rules('jumlah_awal', 'Jumlah Masuk', 'required|numeric');

        if ($this->form_validation->run() === FALSE) {
            $this->session->set_flashdata('error', validation_errors(' ', ' '));
            redirect('bahan/detail/' . $bahan_id);
            return;
        }

        $jumlah = (float) $this->input->post('jumlah_awal', TRUE);
        $payload = array(
            'bahan_id'            => (int) $bahan_id,
            'laboratorium_id'     => $this->input->post('laboratorium_id') ? (int) $this->input->post('laboratorium_id') : NULL,
            'nomor_batch'         => strtoupper($this->input->post('nomor_batch', TRUE)),
            'tanggal_diterima'    => $this->input->post('tanggal_diterima', TRUE) ?: date('Y-m-d'),
            'tanggal_kedaluwarsa' => $this->input->post('tanggal_kedaluwarsa', TRUE) ?: NULL,
            'jumlah_awal'         => $jumlah,
            'jumlah_tersedia'     => $jumlah,
            'lokasi_penyimpanan'  => $this->input->post('lokasi_penyimpanan', TRUE) ?: NULL,
            'keterangan'          => $this->input->post('keterangan', TRUE) ?: NULL
        );

        $user_id = $this->session->userdata('user_id');
        $this->Bahan_model->insert_batch_with_transaksi($payload, $user_id);

        $this->session->set_flashdata('success', 'Batch baru dan stok awal berhasil ditambahkan.');
        redirect('bahan/detail/' . $bahan_id);
    }

    public function pakai_stok($bahan_id)
    {
        if ($this->input->method(TRUE) !== 'POST') {
            show_404();
            return;
        }

        $batch_id = (int) $this->input->post('batch_id', TRUE);
        $jumlah   = (float) $this->input->post('jumlah', TRUE);
        $alasan   = $this->input->post('alasan', TRUE);
        $user_id  = $this->session->userdata('user_id');

        if ($jumlah <= 0 || empty($alasan)) {
            $this->session->set_flashdata('error', 'Jumlah pemakaian harus lebih dari 0 dan alasan harus diisi.');
            redirect('bahan/detail/' . $bahan_id);
            return;
        }

        $result = $this->Bahan_model->record_pengurangan_stok($batch_id, $jumlah, $user_id, $alasan);

        if (!$result) {
            $this->session->set_flashdata('error', 'Gagal memotong stok. Pastikan stok batch mencukupi.');
        } else {
            $this->session->set_flashdata('success', 'Penggunaan bahan berhasil dicatat.');
        }

        redirect('bahan/detail/' . $bahan_id);
    }

    public function hapus($id)
    {
        if ($this->input->method(TRUE) !== 'POST') {
            show_404();
            return;
        }

        if (!$this->Bahan_model->delete($id)) {
            $this->session->set_flashdata('error', 'Bahan tidak dapat dihapus karena sudah memiliki riwayat batch stok.');
        } else {
            $this->session->set_flashdata('success', 'Data bahan berhasil dihapus.');
        }

        redirect('bahan');
    }
}
