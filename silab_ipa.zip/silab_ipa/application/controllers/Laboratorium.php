<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Laboratorium extends Admin_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Laboratorium_model');
        $this->load->library('form_validation');
        $this->load->helper(array('form', 'url'));
    }

    public function index()
    {
        $data['judul'] = 'Master Laboratorium';
        $data['laboratorium'] = $this->Laboratorium_model->get_all();
        $this->load->view('laboratorium/index', $data);
    }

    public function tambah()
    {
        $data['judul'] = 'Tambah Laboratorium';
        $this->load->view('laboratorium/tambah', $data);
    }

    public function simpan()
    {
        if ($this->input->method(TRUE) !== 'POST') {
            show_404();
            return;
        }

        $this->_set_rules();

        if ($this->form_validation->run() === FALSE) {
            $this->tambah();
            return;
        }

        $payload = array(
            'kode'       => strtoupper($this->input->post('kode', TRUE)),
            'nama'       => $this->input->post('nama', TRUE),
            'lokasi'     => $this->input->post('lokasi', TRUE) ?: NULL,
            'kapasitas'  => $this->input->post('kapasitas', TRUE) !== '' ? (int) $this->input->post('kapasitas', TRUE) : NULL,
            'keterangan' => $this->input->post('keterangan', TRUE) ?: NULL,
            'aktif'      => $this->input->post('aktif') ? 1 : 0
        );

        $this->Laboratorium_model->insert($payload);
        $this->session->set_flashdata('success', 'Data laboratorium berhasil ditambahkan.');
        redirect('laboratorium');
    }

    public function edit($id)
    {
        $lab = $this->Laboratorium_model->get_by_id($id);
        if (!$lab) {
            show_404();
            return;
        }

        $data['judul'] = 'Edit Laboratorium';
        $data['lab']   = $lab;
        $this->load->view('laboratorium/edit', $data);
    }

    public function update($id)
    {
        if ($this->input->method(TRUE) !== 'POST') {
            show_404();
            return;
        }

        $lab = $this->Laboratorium_model->get_by_id($id);
        if (!$lab) {
            show_404();
            return;
        }

        $this->_set_rules($id);

        if ($this->form_validation->run() === FALSE) {
            $this->edit($id);
            return;
        }

        $payload = array(
            'kode'       => strtoupper($this->input->post('kode', TRUE)),
            'nama'       => $this->input->post('nama', TRUE),
            'lokasi'     => $this->input->post('lokasi', TRUE) ?: NULL,
            'kapasitas'  => $this->input->post('kapasitas', TRUE) !== '' ? (int) $this->input->post('kapasitas', TRUE) : NULL,
            'keterangan' => $this->input->post('keterangan', TRUE) ?: NULL,
            'aktif'      => $this->input->post('aktif') ? 1 : 0
        );

        $this->Laboratorium_model->update($id, $payload);
        $this->session->set_flashdata('success', 'Data laboratorium berhasil diperbarui.');
        redirect('laboratorium');
    }

    public function hapus($id)
    {
        if ($this->input->method(TRUE) !== 'POST') {
            show_404();
            return;
        }

        $lab = $this->Laboratorium_model->get_by_id($id);
        if (!$lab) {
            show_404();
            return;
        }

        // Cek foreign key constraint
        if ($this->Laboratorium_model->check_usage($id)) {
            $this->session->set_flashdata('error', 'Laboratorium tidak dapat dihapus karena masih digunakan pada data inventaris alat/bahan.');
            redirect('laboratorium');
            return;
        }

        $this->Laboratorium_model->delete($id);
        $this->session->set_flashdata('success', 'Laboratorium berhasil dihapus.');
        redirect('laboratorium');
    }

    private function _set_rules($id = null)
    {
        $unique_kode = 'is_unique[laboratorium.kode]';
        if ($id !== null) {
            $unique_kode = "is_unique[laboratorium.kode.id.{$id}]"; // Jika menggunakan MY_Form_validation atau dicek manual
        }

        $this->form_validation->set_rules('kode', 'Kode Laboratorium', 'required|trim|max_length[20]');
        $this->form_validation->set_rules('nama', 'Nama Laboratorium', 'required|trim|max_length[100]');
        $this->form_validation->set_rules('lokasi', 'Lokasi', 'trim|max_length[150]');
        $this->form_validation->set_rules('kapasitas', 'Kapasitas', 'trim|is_natural');
    }
}
